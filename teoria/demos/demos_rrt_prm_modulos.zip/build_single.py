#!/usr/bin/env python3
"""Genera la versión de un solo archivo de una demo modular.

Uso: python3 build_single.py <carpeta_demo> <salida.html>

Lee index.html, incrusta style.css y concatena los módulos JS en orden de
dependencias (quitando import/export) dentro de un único <script>.
Así el archivo funciona abriéndolo directamente (file://), sin servidor.
"""
import re
import sys
from pathlib import Path

IMPORT_RE = re.compile(r"^\s*import\s+.*?\s+from\s+['\"](\./[^'\"]+)['\"];?\s*$", re.M)
EXPORT_RE = re.compile(r"^export\s+(?=(async\s+)?(function|class|const|let|var)\b)", re.M)


def collect(js_dir: Path, name: str, seen: list):
    if name in seen:
        return
    src = (js_dir / name).read_text(encoding="utf-8")
    for dep in IMPORT_RE.findall(src):
        collect(js_dir, Path(dep).name, seen)
    seen.append(name)


def main():
    demo = Path(sys.argv[1])
    out = Path(sys.argv[2])
    html = (demo / "index.html").read_text(encoding="utf-8")
    css = (demo / "style.css").read_text(encoding="utf-8")
    js_dir = demo / "js"

    order = []
    collect(js_dir, "main.js", order)
    parts = []
    for name in order:
        src = (js_dir / name).read_text(encoding="utf-8")
        src = IMPORT_RE.sub("", src)
        src = EXPORT_RE.sub("", src)
        if re.search(r"^\s*(import|export)\b", src, re.M):
            raise SystemExit(f"{name}: quedan import/export que el script no sabe convertir")
        parts.append(f"// ===== {name} =====\n{src.strip()}\n")
    bundle = "(() => {\n'use strict';\n" + "\n".join(parts) + "})();"

    html = re.sub(r'<link rel="stylesheet" href="style.css">', lambda _: f"<style>\n{css}</style>", html)
    html = re.sub(r'<script type="module" src="js/main.js"></script>', lambda _: f"<script>\n{bundle}\n</script>", html)
    out.write_text(html, encoding="utf-8")
    print(f"{out} ({out.stat().st_size // 1024} KB) ← {', '.join(order)}")


if __name__ == "__main__":
    main()
