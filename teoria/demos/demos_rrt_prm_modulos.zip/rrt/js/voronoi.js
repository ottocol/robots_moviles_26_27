// Regiones de Voronoi de los nodos del árbol sobre una rejilla.
// Cada celda guarda qué nodo tiene más cerca; al añadir un nodo solo se
// actualizan las celdas que le quedan más cerca a él. El número de celdas de
// cada nodo aproxima el área de su región, que (con muestreo uniforme) es
// proporcional a la probabilidad de que ese nodo sea el q_near elegido.
export class VoronoiGrid {
  constructor(width, height, cell = 4) {
    this.cell = cell;
    this.cols = Math.ceil(width / cell);
    this.rows = Math.ceil(height / cell);
    const n = this.cols * this.rows;
    this.owner = new Int32Array(n).fill(-1);
    this.d2 = new Float32Array(n).fill(Infinity);
    this.area = [];
    this.total = n;
    this.maxArea = 0;
    this.off = document.createElement('canvas');
    this.off.width = this.cols;
    this.off.height = this.rows;
    this.offCtx = this.off.getContext('2d');
    this.img = this.offCtx.createImageData(this.cols, this.rows);
    this.dirty = true;
  }

  add(i, x, y) {
    this.area[i] = 0;
    const c = this.cell;
    for (let r = 0, k = 0; r < this.rows; r++) {
      const dy = (r + 0.5) * c - y;
      for (let col = 0; col < this.cols; col++, k++) {
        const dx = (col + 0.5) * c - x;
        const d = dx * dx + dy * dy;
        if (d < this.d2[k]) {
          const o = this.owner[k];
          if (o >= 0) this.area[o]--;
          this.owner[k] = i;
          this.d2[k] = d;
          this.area[i]++;
        }
      }
    }
    this.maxArea = 0;
    for (const a of this.area) if (a > this.maxArea) this.maxArea = a;
    this.dirty = true;
  }

  fraction(i) { return (this.area[i] || 0) / this.total; }

  // Color por área: claro = región pequeña, naranja intenso = región grande
  paint(ctx, width, height, highlight = -1) {
    if (this.dirty || this.lastHighlight !== highlight) {
      const data = this.img.data;
      const lo = [255, 247, 232], hi = [234, 106, 20];
      const cols = this.cols;
      for (let k = 0; k < this.owner.length; k++) {
        const o = this.owner[k];
        const t = o >= 0 && this.maxArea ? Math.sqrt(this.area[o] / this.maxArea) : 0;
        let r = lo[0] + (hi[0] - lo[0]) * t;
        let g = lo[1] + (hi[1] - lo[1]) * t;
        let b = lo[2] + (hi[2] - lo[2]) * t;
        // borde entre regiones
        const right = (k + 1) % cols !== 0 ? this.owner[k + 1] : o;
        const below = k + cols < this.owner.length ? this.owner[k + cols] : o;
        if (right !== o || below !== o) { r *= 0.72; g *= 0.72; b *= 0.72; }
        if (o === highlight) { r = r * 0.45 + 47 * 0.55; g = g * 0.45 + 111 * 0.55; b = b * 0.45 + 179 * 0.55; }
        const p = k * 4;
        data[p] = r; data[p + 1] = g; data[p + 2] = b; data[p + 3] = 255;
      }
      this.offCtx.putImageData(this.img, 0, 0);
      this.dirty = false;
      this.lastHighlight = highlight;
    }
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(this.off, 0, 0, this.cols * this.cell, this.rows * this.cell);
    ctx.restore();
  }
}
