// Rapidly-exploring Random Tree en (x, y) o en (x, y, θ)
import { WORLD_W, WORLD_H, pointFree, segmentFree, poseFree, se2EdgeFree, se2Dist, angDiff } from './geometry.js';

export class RRT {
  constructor({ mode, obstacles, start, goal, step, goalBias, radius, robot, rng, counter }) {
    this.mode = mode;               // 'point' | 'se2'
    this.obstacles = obstacles;
    this.goal = goal;
    this.step = step;               // Δq
    this.goalBias = goalBias;       // probabilidad de muestrear el objetivo
    this.radius = radius;
    this.robot = robot;
    this.rng = rng;
    this.counter = counter;
    // en (x, y, θ) un radián pesa lo que avanza la esquina del robot al girarlo
    this.wTh = mode === 'se2' ? Math.hypot(robot.L, robot.W) / 2 : 0;
    this.nodes = [{ x: start.x, y: start.y, th: start.th || 0, parent: -1 }];
    this.iter = 0;
    this.rejects = 0;
    this.done = false;
    this.goalIdx = -1;
  }

  dist(a, b) {
    return this.mode === 'se2' ? se2Dist(a, b, this.wTh) : Math.hypot(b.x - a.x, b.y - a.y);
  }

  poseOk(q) {
    return this.mode === 'se2'
      ? poseFree(q.x, q.y, q.th, this.robot, this.obstacles, this.counter)
      : pointFree(q.x, q.y, this.radius, this.obstacles, this.counter);
  }

  edgeOk(a, b) {
    return this.mode === 'se2'
      ? se2EdgeFree(a, b, this.robot, this.obstacles, this.counter)
      : segmentFree(a.x, a.y, b.x, b.y, this.radius, this.obstacles, this.counter);
  }

  // RAND_CONF: muestreo uniforme del espacio de configuraciones (con sesgo al objetivo)
  sample() {
    if (this.rng() < this.goalBias) return { x: this.goal.x, y: this.goal.y, th: this.goal.th || 0, biased: true };
    return {
      x: this.rng() * WORLD_W,
      y: this.rng() * WORLD_H,
      th: this.mode === 'se2' ? this.rng() * 2 * Math.PI - Math.PI : 0,
      biased: false,
    };
  }

  // NEAREST_VERTEX
  nearest(q) {
    let best = 0, bd = Infinity;
    for (let i = 0; i < this.nodes.length; i++) {
      const d = this.dist(this.nodes[i], q);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  // NEW_CONF: avanzar Δq desde q_near hacia q_rand
  steer(a, q) {
    const d = this.dist(a, q);
    if (d <= this.step) return { x: q.x, y: q.y, th: q.th };
    const t = this.step / d;
    return { x: a.x + (q.x - a.x) * t, y: a.y + (q.y - a.y) * t, th: a.th + angDiff(a.th, q.th) * t };
  }

  // Una iteración del bucle de BuildRRT, más la comprobación de colisión y de llegada
  stepOnce() {
    if (this.done) return null;
    this.iter++;
    const qrand = this.sample();
    const nearIdx = this.nearest(qrand);
    const qnear = this.nodes[nearIdx];
    const qnew = this.steer(qnear, qrand);
    const ok = this.edgeOk(qnear, qnew);
    const info = { qrand, nearIdx, qnew, ok, newIdx: -1, reached: false };
    if (!ok) {
      this.rejects++;
      return info;
    }
    this.nodes.push({ ...qnew, parent: nearIdx });
    info.newIdx = this.nodes.length - 1;
    const g = { x: this.goal.x, y: this.goal.y, th: this.goal.th || 0 };
    if (this.dist(qnew, g) <= this.step && this.edgeOk(qnew, g)) {
      if (this.dist(qnew, g) > 1e-6) this.nodes.push({ ...g, parent: info.newIdx });
      this.goalIdx = this.nodes.length - 1;
      this.done = true;
      info.reached = true;
    }
    return info;
  }

  path() {
    if (this.goalIdx < 0) return null;
    const out = [];
    for (let i = this.goalIdx; i !== -1; i = this.nodes[i].parent) out.push(this.nodes[i]);
    return out.reverse();
  }

  pathLength(path) {
    let L = 0;
    for (let i = 1; i < path.length; i++) L += Math.hypot(path[i].x - path[i - 1].x, path[i].y - path[i - 1].y);
    return L;
  }

  // Recorte de atajos: unir dos poses no consecutivas si el tramo directo es libre
  shortcut(path, rng, tries = 300) {
    const p = path.slice();
    for (let t = 0; t < tries && p.length > 2; t++) {
      const i = Math.floor(rng() * (p.length - 2));
      const j = i + 2 + Math.floor(rng() * (p.length - i - 2));
      if (j >= p.length) continue;
      if (this.edgeOk(p[i], p[j])) p.splice(i + 1, j - i - 1);
    }
    return p;
  }
}
