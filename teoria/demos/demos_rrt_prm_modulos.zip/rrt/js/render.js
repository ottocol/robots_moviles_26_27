// Dibujo de la escena del RRT
import { WORLD_W, WORLD_H, obbCorners } from './geometry.js';

export const COLORS = {
  bg: '#fbfbfd', grid: '#eef0f5', obstacle: '#2b2d42', inflate: '#f6dfc6', circ: '#f2c4c4',
  edge: '#6f9bd6', node: '#1f4f8a', path: '#d4148a', pathOld: '#d4148a',
  start: '#2e9e5b', goal: '#d64545', rand: '#6b7280', near: '#2f6fb3', newOk: '#2e9e5b', bad: '#d64545',
  robot: '#7b2ff7',
};

const FONT = '600 13px "Avenir Next", Avenir, system-ui, sans-serif';

function grid(ctx) {
  ctx.strokeStyle = COLORS.grid;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 40; x < WORLD_W; x += 40) { ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, WORLD_H); }
  for (let y = 40; y < WORLD_H; y += 40) { ctx.moveTo(0, y + 0.5); ctx.lineTo(WORLD_W, y + 0.5); }
  ctx.stroke();
}

function inflated(ctx, obstacles, r, color) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.lineJoin = 'round';
  ctx.lineWidth = 2 * r;
  for (const o of obstacles) {
    ctx.beginPath();
    ctx.rect(o.x, o.y, o.w, o.h);
    ctx.fill();
    ctx.stroke();
  }
  ctx.fillRect(0, 0, WORLD_W, r);
  ctx.fillRect(0, WORLD_H - r, WORLD_W, r);
  ctx.fillRect(0, 0, r, WORLD_H);
  ctx.fillRect(WORLD_W - r, 0, r, WORLD_H);
  ctx.restore();
}

function label(ctx, text, x, y, color) {
  ctx.font = FONT;
  ctx.textAlign = 'center';
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = 'rgba(255,255,255,0.92)';
  ctx.strokeText(text, x, y);
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

export function footprint(ctx, q, robot, { fill = null, stroke = '#333', dash = null, alpha = 1, lw = 1.5 } = {}) {
  const cs = obbCorners(q.x, q.y, q.th, robot.L, robot.W);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  cs.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) {
    if (dash) ctx.setLineDash(dash);
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lw;
    ctx.stroke();
  }
  // frente del robot
  const c = Math.cos(q.th), s = Math.sin(q.th), f = robot.L / 2;
  ctx.beginPath();
  ctx.moveTo(q.x + c * (f - 2), q.y + s * (f - 2));
  ctx.lineTo(q.x + c * (f - 14) - s * 7, q.y + s * (f - 14) + c * 7);
  ctx.lineTo(q.x + c * (f - 14) + s * 7, q.y + s * (f - 14) - c * 7);
  ctx.closePath();
  ctx.fillStyle = stroke || '#333';
  ctx.fill();
  ctx.restore();
}

function endpoint(ctx, s, q, color, text) {
  if (s.mode === 'se2') {
    footprint(ctx, q, s.robot, { fill: color + '55', stroke: color, lw: 2 });
    label(ctx, text, q.x, q.y - Math.max(s.robot.L, s.robot.W) / 2 - 8, color);
  } else {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(q.x, q.y, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    label(ctx, text, q.x, q.y - 14, color);
  }
}

// interpolación de una pose a lo largo de un camino (para dibujar el robot)
export function poseAlong(path, t, angDiffFn) {
  const segs = [];
  let total = 0;
  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1], b = path[i];
    const L = Math.hypot(b.x - a.x, b.y - a.y) + Math.abs(angDiffFn(a.th, b.th)) * 20;
    segs.push(L);
    total += L;
  }
  let d = (t % 1) * total;
  for (let i = 0; i < segs.length; i++) {
    if (d <= segs[i] || i === segs.length - 1) {
      const a = path[i], b = path[i + 1], u = segs[i] ? Math.min(d / segs[i], 1) : 1;
      return { x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * u, th: a.th + angDiffFn(a.th, b.th) * u };
    }
    d -= segs[i];
  }
  return path[path.length - 1];
}

export function drawScene(ctx, s) {
  ctx.fillStyle = COLORS.bg;
  ctx.fillRect(0, 0, WORLD_W, WORLD_H);
  const rrt = s.rrt;
  const vorOn = s.mode === 'point' && s.show.vor && s.vor;
  if (vorOn) s.vor.paint(ctx, WORLD_W, WORLD_H, s.show.markers && s.last ? s.last.nearIdx : -1);
  else grid(ctx);

  if (s.mode === 'se2' && s.show.circ) inflated(ctx, s.obstacles, s.circR, COLORS.circ);
  if (s.mode === 'point' && s.show.inflate && !vorOn) inflated(ctx, s.obstacles, s.radius, COLORS.inflate);
  ctx.fillStyle = COLORS.obstacle;
  for (const o of s.obstacles) ctx.fillRect(o.x, o.y, o.w, o.h);
  if (s.mode === 'se2' && s.show.circ) {
    label(ctx, `Obstáculos dilatados con el radio circunscrito (R = ${Math.round(s.circR)} px)`, WORLD_W / 2, 22, '#9b1c1c');
  }

  if (rrt) {
    // árbol
    ctx.strokeStyle = COLORS.edge;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    for (let i = 1; i < rrt.nodes.length; i++) {
      const a = rrt.nodes[i], p = rrt.nodes[a.parent];
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(a.x, a.y);
    }
    ctx.stroke();
    if (s.mode === 'se2') {
      // orientación de cada nodo
      ctx.strokeStyle = COLORS.node;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (const n of rrt.nodes) {
        ctx.moveTo(n.x, n.y);
        ctx.lineTo(n.x + Math.cos(n.th) * 9, n.y + Math.sin(n.th) * 9);
      }
      ctx.stroke();
    }
    ctx.fillStyle = COLORS.node;
    for (const n of rrt.nodes) {
      ctx.beginPath();
      ctx.arc(n.x, n.y, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // camino
  const path = s.shortPath || s.path;
  if (s.shortPath && s.path) {
    ctx.save();
    ctx.strokeStyle = COLORS.pathOld;
    ctx.globalAlpha = 0.35;
    ctx.setLineDash([5, 4]);
    ctx.lineWidth = 2;
    ctx.beginPath();
    s.path.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();
    ctx.restore();
  }
  if (path) {
    if (s.mode === 'se2' && !s.animating) {
      for (let i = 0; i <= 24; i++) footprint(ctx, poseAlong(path, i / 24.0001, s.angDiff), s.robot, { stroke: COLORS.path, alpha: 0.25, lw: 1 });
    }
    ctx.strokeStyle = COLORS.path;
    ctx.lineWidth = 4;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    path.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();
  }

  // última iteración: q_rand, q_near, q_new
  const L = s.last;
  if (rrt && L && s.show.markers && !s.animating && !rrt.done) {
    const near = rrt.nodes[L.nearIdx];
    // etiquetas de q_near y q_new en lados opuestos para que no se solapen
    let ux = L.qnew.x - near.x, uy = L.qnew.y - near.y;
    const un = Math.hypot(ux, uy) || 1;
    ux /= un; uy /= un;
    if (un < 1e-6) { ux = 0; uy = -1; }
    ctx.save();
    ctx.setLineDash([5, 4]);
    ctx.strokeStyle = COLORS.rand;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(near.x, near.y);
    ctx.lineTo(L.qrand.x, L.qrand.y);
    ctx.stroke();
    ctx.restore();
    if (s.mode === 'se2') {
      footprint(ctx, L.qrand, s.robot, { stroke: COLORS.rand, dash: [4, 3], lw: 1.5 });
      footprint(ctx, L.qnew, s.robot, { fill: (L.ok ? COLORS.newOk : COLORS.bad) + '33', stroke: L.ok ? COLORS.newOk : COLORS.bad, lw: 2 });
    }
    ctx.strokeStyle = COLORS.rand;
    ctx.fillStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(L.qrand.x, L.qrand.y, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    label(ctx, L.qrand.biased ? 'q_rand = objetivo' : 'q_rand', L.qrand.x, L.qrand.y - 10, '#374151');
    ctx.strokeStyle = COLORS.near;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(near.x, near.y, 7, 0, Math.PI * 2);
    ctx.stroke();
    label(ctx, 'q_near', near.x - ux * 24, near.y - uy * 24 + 4, COLORS.near);
    const c = L.ok ? COLORS.newOk : COLORS.bad;
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.arc(L.qnew.x, L.qnew.y, 5, 0, Math.PI * 2);
    ctx.fill();
    // q_new: hacia un lado, perpendicular al tramo, para no tapar q_rand
    label(ctx, L.ok ? 'q_new' : 'q_new (choca)', L.qnew.x - uy * 22, L.qnew.y + ux * 22 + 4, c);
  }

  endpoint(ctx, s, s.start, COLORS.start, 'Inicio');
  endpoint(ctx, s, s.goal, COLORS.goal, 'Objetivo');

  if (s.animating && path) {
    const q = poseAlong(path, s.animT, s.angDiff);
    if (s.mode === 'se2') footprint(ctx, q, s.robot, { fill: COLORS.robot + 'cc', stroke: COLORS.robot, lw: 2 });
    else {
      ctx.fillStyle = COLORS.robot;
      ctx.beginPath();
      ctx.arc(q.x, q.y, Math.max(s.radius, 5), 0, Math.PI * 2);
      ctx.fill();
    }
  }

  if (s.draft) {
    const d = s.draft;
    ctx.save();
    ctx.fillStyle = 'rgba(43,45,66,0.35)';
    ctx.strokeStyle = COLORS.obstacle;
    ctx.setLineDash([4, 3]);
    ctx.fillRect(d.x, d.y, d.w, d.h);
    ctx.strokeRect(d.x, d.y, d.w, d.h);
    ctx.restore();
  }
}
