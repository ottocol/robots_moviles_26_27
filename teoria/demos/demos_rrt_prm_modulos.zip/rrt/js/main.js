// Interfaz de la demo RRT
import { makeRng } from './rng.js';
import { WORLD_W, WORLD_H, hitObstacle, angDiff, pointFree, poseFree } from './geometry.js';
import { POINT_MAPS, SE2_MAPS } from './maps.js';
import { RRT } from './rrt.js';
import { VoronoiGrid } from './voronoi.js';
import { drawScene } from './render.js';

const $ = (id) => document.getElementById(id);
const canvas = $('canvas');
const ctx = canvas.getContext('2d');

// Robot rectangular omnidireccional: una plataforma que lleva una carga larga
const ROBOT = { L: 84, W: 28 };
const CIRC_R = Math.hypot(ROBOT.L, ROBOT.W) / 2;
const GRID_CELL = 5, GRID_DEG = 5;

const SPEED_ITERS = [0.1, 0.5, 1, 3, 10, 40, 200];
const SPEED_NAMES = ['1 iter. cada 10 fotogramas', '1 iter. cada 2 fotogramas', '1 iter./fotograma', '3 iter./fotograma', '10 iter./fotograma', '40 iter./fotograma', '200 iter./fotograma'];
const MAX_ITERS = 30000;

const state = {
  mode: 'point', mapId: 'rooms', obstacles: [], start: null, goal: null,
  seed: 1, step: 25, bias: 0.05, speedIdx: 3, radius: 6,
  robot: ROBOT, circR: CIRC_R, angDiff,
  rrt: null, vor: null, counter: { checks: 0 },
  running: false, acc: 0, last: null, lastFrac: 0,
  path: null, shortPath: null, animating: false, animT: 0,
  show: { vor: true, markers: true, circ: false, inflate: true },
  drag: null, draft: null, invalid: '',
};

// ---------- lienzo ----------
function setupCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = WORLD_W * dpr;
  canvas.height = WORLD_H * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function toWorld(e) {
  const r = canvas.getBoundingClientRect();
  return { x: (e.clientX - r.left) * WORLD_W / r.width, y: (e.clientY - r.top) * WORLD_H / r.height };
}

// ---------- estado ----------
const maps = () => (state.mode === 'se2' ? SE2_MAPS : POINT_MAPS);

function loadMap(id) {
  state.mapId = id;
  const m = maps()[id].make();
  state.obstacles = m.obstacles;
  state.start = { ...m.start };
  state.goal = { ...m.goal };
  resetTree();
}

function configFree(q) {
  return state.mode === 'se2'
    ? poseFree(q.x, q.y, q.th, ROBOT, state.obstacles, null)
    : pointFree(q.x, q.y, state.radius, state.obstacles, null);
}

function resetTree() {
  state.counter = { checks: 0 };
  state.rrt = new RRT({
    mode: state.mode, obstacles: state.obstacles, start: state.start, goal: state.goal,
    step: state.step, goalBias: state.bias, radius: state.radius, robot: ROBOT,
    rng: makeRng(state.seed), counter: state.counter,
  });
  state.vor = null;
  if (state.mode === 'point') {
    state.vor = new VoronoiGrid(WORLD_W, WORLD_H, 4);
    state.vor.add(0, state.start.x, state.start.y);
  }
  state.running = false;
  state.acc = 0;
  state.last = null;
  state.path = null;
  state.shortPath = null;
  state.animating = false;
  state.invalid = !configFree(state.start) ? 'start' : !configFree(state.goal) ? 'goal' : '';
  syncButtons();
  setMessage();
}

function iterate() {
  const rrt = state.rrt;
  if (!rrt || rrt.done || state.invalid) return null;
  if (rrt.iter >= MAX_ITERS) { state.running = false; return null; }
  const info = rrt.stepOnce();
  // probabilidad de que q_near fuese elegido = área de su región / área total
  state.lastFrac = state.vor ? state.vor.fraction(info.nearIdx) : 0;
  if (state.vor && info.newIdx >= 0) {
    state.vor.add(info.newIdx, info.qnew.x, info.qnew.y);
    if (info.reached && rrt.goalIdx !== info.newIdx) state.vor.add(rrt.goalIdx, state.goal.x, state.goal.y);
  }
  state.last = info;
  if (info.reached) {
    state.running = false;
    state.path = rrt.path();
  }
  return info;
}

// ---------- textos ----------
const fmt = (v, d = 0) => v.toLocaleString('es-ES', { maximumFractionDigits: d, minimumFractionDigits: d });

function setMessage() {
  const rrt = state.rrt, L = state.last;
  let t;
  if (state.invalid) {
    t = `El ${state.invalid === 'start' ? 'inicio' : 'objetivo'} está en colisión: muévelo${state.mode === 'se2' ? ' o gíralo con la rueda del ratón' : ''}.`;
  } else if (rrt.done) {
    const len = rrt.pathLength(state.shortPath || state.path);
    t = `<b>Objetivo alcanzado</b> en ${fmt(rrt.iter)} iteraciones con ${fmt(rrt.nodes.length)} nodos (camino de ${fmt(len)} px). `
      + (state.shortPath ? 'Tras recortar atajos el camino es más corto, pero sigue sin ser óptimo.' : 'El camino es quebrado y no es óptimo: prueba «Recortar atajos».');
  } else if (rrt.iter >= MAX_ITERS) {
    t = `Se ha llegado al límite de ${fmt(MAX_ITERS)} iteraciones sin alcanzar el objetivo.`;
  } else if (!L) {
    t = state.mode === 'se2'
      ? '<b>Espacio de configuraciones (x, y, θ):</b> cada muestra es una pose completa del robot. Pulsa «Paso» para ver una iteración o «Reproducir».'
      : '<b>El árbol crece desde el inicio.</b> Pulsa «Paso» para ver una iteración: muestra q_rand, busca el nodo más cercano q_near y avanza Δq hacia q_rand.';
  } else if (L.qrand.biased) {
    t = `q_rand <b>es el propio objetivo</b> (sesgo del ${Math.round(state.bias * 100)} %): el árbol intenta acercarse directamente a él. ${L.ok ? 'Se añade q_new.' : 'El tramo choca: se descarta.'}`;
  } else if (state.mode === 'point' && state.show.vor) {
    t = `q_rand ha caído en la región de Voronoi de q_near (en azul), que ocupa el <b>${fmt(state.lastFrac * 100, 1)} %</b> del mapa: esa es la probabilidad de que q_near fuese el elegido. `
      + (L.ok ? 'Se avanza Δq y se añade q_new.' : 'El tramo q_near → q_new choca: se descarta.');
  } else {
    t = L.ok ? 'Se avanza Δq desde q_near hacia q_rand y se añade q_new al árbol.' : 'El tramo q_near → q_new choca con un obstáculo: se descarta y se vuelve a muestrear.';
  }
  $('message').innerHTML = t;
}

function updateStats() {
  const rrt = state.rrt;
  const path = state.shortPath || state.path;
  const rows = [
    ['Iteraciones', fmt(rrt.iter)],
    ['Nodos del árbol', fmt(rrt.nodes.length)],
    ['Extensiones descartadas', fmt(rrt.rejects)],
    ['Comprobaciones de colisión', fmt(state.counter.checks)],
    ['Longitud del camino', path ? `${fmt(rrt.pathLength(path))} px` : '–'],
  ];
  if (state.mode === 'se2') {
    const cells = Math.ceil(WORLD_W / GRID_CELL) * Math.ceil(WORLD_H / GRID_CELL) * (360 / GRID_DEG);
    rows.push([`Rejilla (x, y, θ) de ${GRID_CELL} px y ${GRID_DEG}°`, `${fmt(cells)} celdas`]);
  }
  $('stats').innerHTML = rows.map(([a, b]) => `<dt>${a}</dt><dd>${b}</dd>`).join('');
}

function syncButtons() {
  const rrt = state.rrt;
  const finished = rrt.done || rrt.iter >= MAX_ITERS || !!state.invalid;
  $('btnPlay').textContent = state.running ? '⏸ Pausa' : '▶ Reproducir';
  $('btnPlay').disabled = finished;
  $('btnStep').disabled = finished;
  $('btnEnd').disabled = finished;
  $('btnShortcut').disabled = !state.path;
  $('btnAnimate').disabled = !state.path;
  $('btnAnimate').textContent = state.animating ? '■ Parar robot' : 'Animar robot';
  const se2 = state.mode === 'se2';
  $('rowVor').hidden = se2;
  $('rowInflate').hidden = se2;
  $('rowCirc').hidden = !se2;
  $('rowRadius').hidden = se2;
  $('noteSe2').hidden = !se2;
  $('legendVor').hidden = se2 || !state.show.vor;
}

// ---------- bucle ----------
let msgTick = 0;
function frame() {
  if (state.running) {
    state.acc += SPEED_ITERS[state.speedIdx];
    let n = Math.floor(state.acc);
    state.acc -= n;
    while (n-- > 0 && state.running) iterate();
    if (!state.running) syncButtons();
  }
  if (state.animating) state.animT = (state.animT + 0.0025) % 1;
  drawScene(ctx, state);
  if (++msgTick > 5) { setMessage(); msgTick = 0; }
  updateStats();
  requestAnimationFrame(frame);
}

// ---------- controles ----------
function bindSlider(id, outId, fn, label = (v) => v) {
  const el = $(id), out = $(outId);
  const update = (reset) => { const v = +el.value; out.textContent = label(v); fn(v, reset); };
  el.addEventListener('input', () => update(true));
  update(false);
}

function fillMaps() {
  const sel = $('map');
  sel.innerHTML = Object.entries(maps()).map(([k, m]) => `<option value="${k}">${m.name}</option>`).join('');
  sel.value = state.mapId;
}

function initControls() {
  $('mode').addEventListener('change', (e) => {
    state.mode = e.target.value;
    state.mapId = Object.keys(maps())[0];
    fillMaps();
    loadMap(state.mapId);
  });
  fillMaps();
  $('map').addEventListener('change', (e) => loadMap(e.target.value));

  bindSlider('step', 'stepOut', (v, r) => { state.step = v; if (r) resetTree(); }, (v) => `${v} px`);
  bindSlider('bias', 'biasOut', (v, r) => { state.bias = v / 100; if (r) resetTree(); }, (v) => `${v} %`);
  bindSlider('radius', 'rOut', (v, r) => { state.radius = v; if (r) resetTree(); }, (v) => `${v} px`);
  bindSlider('speed', 'speedOut', (v) => { state.speedIdx = v; }, (v) => SPEED_NAMES[v]);

  $('btnStep').addEventListener('click', () => { state.running = false; iterate(); syncButtons(); setMessage(); });
  $('btnPlay').addEventListener('click', () => { state.running = !state.running; syncButtons(); });
  $('btnEnd').addEventListener('click', () => {
    state.running = false;
    const t0 = performance.now();
    while (!state.rrt.done && state.rrt.iter < MAX_ITERS && performance.now() - t0 < 4000) iterate();
    syncButtons();
    setMessage();
  });
  $('btnReset').addEventListener('click', () => resetTree());
  $('btnSeed').addEventListener('click', () => { state.seed++; $('seedOut').textContent = `(${state.seed})`; resetTree(); });
  $('seedOut').textContent = `(${state.seed})`;
  $('btnShortcut').addEventListener('click', () => {
    if (!state.path) return;
    state.shortPath = state.rrt.shortcut(state.shortPath || state.path, makeRng(state.seed * 7919 + 1));
    setMessage();
  });
  $('btnAnimate').addEventListener('click', () => { state.animating = !state.animating; state.animT = 0; syncButtons(); });

  $('chkVor').addEventListener('change', (e) => { state.show.vor = e.target.checked; syncButtons(); setMessage(); });
  $('chkMarkers').addEventListener('change', (e) => { state.show.markers = e.target.checked; });
  $('chkCirc').addEventListener('change', (e) => { state.show.circ = e.target.checked; });
  $('chkInflate').addEventListener('change', (e) => { state.show.inflate = e.target.checked; });
}

// ---------- ratón ----------
function nearEnd(p) {
  const tol = state.mode === 'se2' ? 34 : 16;
  if (Math.hypot(p.x - state.start.x, p.y - state.start.y) < tol) return 'start';
  if (Math.hypot(p.x - state.goal.x, p.y - state.goal.y) < tol) return 'goal';
  return null;
}

function initPointer() {
  canvas.addEventListener('pointerdown', (e) => {
    const p = toWorld(e);
    canvas.setPointerCapture(e.pointerId);
    const end = nearEnd(p);
    if (end) state.drag = { kind: end };
    else {
      const hit = hitObstacle(p.x, p.y, state.obstacles);
      state.drag = hit >= 0 ? { kind: 'delete', index: hit, x0: p.x, y0: p.y } : { kind: 'draw', x0: p.x, y0: p.y };
    }
  });
  canvas.addEventListener('pointermove', (e) => {
    const p = toWorld(e);
    const d = state.drag;
    if (!d) {
      canvas.style.cursor = nearEnd(p) ? 'grab' : hitObstacle(p.x, p.y, state.obstacles) >= 0 ? 'pointer' : 'crosshair';
      return;
    }
    const cx = Math.min(Math.max(p.x, 0), WORLD_W), cy = Math.min(Math.max(p.y, 0), WORLD_H);
    if (d.kind === 'start' || d.kind === 'goal') {
      state[d.kind] = { ...state[d.kind], x: cx, y: cy };
      resetTree();
    } else if (d.kind === 'draw') {
      state.draft = { x: Math.min(d.x0, cx), y: Math.min(d.y0, cy), w: Math.abs(cx - d.x0), h: Math.abs(cy - d.y0) };
    } else if (d.kind === 'delete' && Math.hypot(p.x - d.x0, p.y - d.y0) > 5) {
      d.kind = 'none';
    }
  });
  const end = () => {
    const d = state.drag;
    state.drag = null;
    if (!d) return;
    if (d.kind === 'draw' && state.draft && state.draft.w >= 8 && state.draft.h >= 8) {
      const r = state.draft;
      state.obstacles.push({ x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.w), h: Math.round(r.h) });
      resetTree();
    } else if (d.kind === 'delete') {
      state.obstacles.splice(d.index, 1);
      resetTree();
    }
    state.draft = null;
  };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);
  // en (x, y, θ), la rueda del ratón gira el inicio o el objetivo
  canvas.addEventListener('wheel', (e) => {
    if (state.mode !== 'se2') return;
    const which = nearEnd(toWorld(e));
    if (!which) return;
    e.preventDefault();
    state[which] = { ...state[which], th: state[which].th + Math.sign(e.deltaY) * Math.PI / 12 };
    resetTree();
  }, { passive: false });
}

setupCanvas();
window.addEventListener('resize', setupCanvas);
initControls();
initPointer();
loadMap(state.mapId);
requestAnimationFrame(frame);

window.rrtDemo = state;
