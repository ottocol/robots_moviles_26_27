// Geometría y comprobación de colisiones.
// El mundo mide WORLD_W x WORLD_H unidades (1 unidad = 1 píxel del lienzo).
// Los obstáculos son rectángulos alineados con los ejes {x, y, w, h}.

export const WORLD_W = 960;
export const WORLD_H = 600;

// Distancia de un punto a un rectángulo (0 si está dentro)
export function pointRectDist(px, py, r) {
  const dx = Math.max(r.x - px, 0, px - (r.x + r.w));
  const dy = Math.max(r.y - py, 0, py - (r.y + r.h));
  return Math.hypot(dx, dy);
}

// Índice del obstáculo que contiene el punto, o -1
export function hitObstacle(px, py, obstacles) {
  for (let i = obstacles.length - 1; i >= 0; i--) {
    const o = obstacles[i];
    if (px >= o.x && px <= o.x + o.w && py >= o.y && py <= o.y + o.h) return i;
  }
  return -1;
}

// ---------- Robot circular (CSpace 2D) ----------
// Comprobar un robot de radio r equivale a comprobar un punto contra los
// obstáculos dilatados r (suma de Minkowski).
export function pointFree(px, py, radius, obstacles, counter) {
  if (counter) counter.checks++;
  if (px < radius || py < radius || px > WORLD_W - radius || py > WORLD_H - radius) return false;
  for (const o of obstacles) {
    if (pointRectDist(px, py, o) < radius) return false;
  }
  return true;
}

// Un segmento es libre si lo son todos sus puntos, muestreados cada `step`
export function segmentFree(ax, ay, bx, by, radius, obstacles, counter, step = 3) {
  const n = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay) / step));
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    if (!pointFree(ax + (bx - ax) * t, ay + (by - ay) * t, radius, obstacles, counter)) return false;
  }
  return true;
}

// ---------- Robot rectangular (CSpace 3D: x, y, θ) ----------

// Diferencia angular b - a en (-π, π]
export function angDiff(a, b) {
  let d = b - a;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d <= -Math.PI) d += 2 * Math.PI;
  return d;
}

// Esquinas del rectángulo L x W centrado en (x, y) y girado θ
export function obbCorners(x, y, th, L, W) {
  const c = Math.cos(th), s = Math.sin(th), hl = L / 2, hw = W / 2;
  return [
    [x + c * hl - s * hw, y + s * hl + c * hw],
    [x - c * hl - s * hw, y - s * hl + c * hw],
    [x - c * hl + s * hw, y - s * hl - c * hw],
    [x + c * hl + s * hw, y + s * hl - c * hw],
  ];
}

function projectRange(points, ax, ay) {
  let mn = Infinity, mx = -Infinity;
  for (const p of points) {
    const v = p[0] * ax + p[1] * ay;
    if (v < mn) mn = v;
    if (v > mx) mx = v;
  }
  return [mn, mx];
}

// Teorema del eje separador entre el rectángulo girado y uno alineado
export function obbHitsRect(corners, r) {
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const [px, py] of corners) {
    if (px < minX) minX = px;
    if (px > maxX) maxX = px;
    if (py < minY) minY = py;
    if (py > maxY) maxY = py;
  }
  if (maxX <= r.x || minX >= r.x + r.w || maxY <= r.y || minY >= r.y + r.h) return false;
  const rc = [[r.x, r.y], [r.x + r.w, r.y], [r.x + r.w, r.y + r.h], [r.x, r.y + r.h]];
  for (let k = 0; k < 2; k++) {
    const ax = corners[k + 1][0] - corners[k][0];
    const ay = corners[k + 1][1] - corners[k][1];
    const [a0, a1] = projectRange(corners, ax, ay);
    const [b0, b1] = projectRange(rc, ax, ay);
    if (a1 <= b0 || b1 <= a0) return false;
  }
  return true;
}

export function poseFree(x, y, th, robot, obstacles, counter) {
  if (counter) counter.checks++;
  const cs = obbCorners(x, y, th, robot.L, robot.W);
  for (const [px, py] of cs) {
    if (px < 0 || py < 0 || px > WORLD_W || py > WORLD_H) return false;
  }
  for (const o of obstacles) {
    if (obbHitsRect(cs, o)) return false;
  }
  return true;
}

// Métrica en (x, y, θ): el ángulo se pondera con wTh (unidades de longitud por radián)
export function se2Dist(a, b, wTh) {
  return Math.hypot(b.x - a.x, b.y - a.y, wTh * angDiff(a.th, b.th));
}

// Tramo libre en (x, y, θ): interpolación lineal comprobando poses intermedias.
// El paso se elige para que ninguna esquina avance más de `step` entre comprobaciones.
export function se2EdgeFree(a, b, robot, obstacles, counter, step = 3) {
  const dth = angDiff(a.th, b.th);
  const trans = Math.hypot(b.x - a.x, b.y - a.y);
  const sweep = Math.abs(dth) * Math.hypot(robot.L, robot.W) / 2;
  const n = Math.max(1, Math.ceil((trans + sweep) / step));
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    if (!poseFree(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.th + dth * t, robot, obstacles, counter)) {
      return false;
    }
  }
  return true;
}
