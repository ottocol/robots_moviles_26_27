// Interfaz de la demo PRM
import { makeRng } from './rng.js';
import { WORLD_W, WORLD_H, hitObstacle } from './geometry.js';
import { POINT_MAPS } from './maps.js';
import { PRM } from './prm.js';
import { drawScene, COMP_COLORS } from './render.js';

const $ = (id) => document.getElementById(id);
const canvas = $('canvas');
const ctx = canvas.getContext('2d');

// pasos de animación por fotograma para cada nivel de velocidad
const SPEED_STEPS = [0.125, 1, 4, 25, Infinity];
const SPEED_NAMES = ['Muy lenta', 'Lenta', 'Normal', 'Rápida', 'Instantánea'];

const state = {
  mapId: 'rooms', obstacles: [], start: null, goal: null,
  seed: 1, n: 250, k: 8, radius: 8, speed: 2,
  prm: null, counter: { checks: 0 }, rng: null,
  phase: 'empty',           // empty | sampling | sampled | connecting | built
  queue: [], gen: null, acc: 0,
  ms: { sample: 0, connect: 0 }, buildChecks: 0,
  current: null, query: null, queryMs: 0,
  show: { inflate: true, rejected: true, comps: false },
  compColor: null, compCount: 0, compLargest: 0,
  drag: null, draft: null,
};

// ---------- lienzo ----------
function setupCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = WORLD_W * dpr;
  canvas.height = WORLD_H * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function toWorld(e) {
  const r = canvas.getBoundingClientRect();
  return { x: (e.clientX - r.left) * WORLD_W / r.width, y: (e.clientY - r.top) * WORLD_H / r.height };
}

// ---------- estado ----------
function loadMap(id) {
  state.mapId = id;
  const m = POINT_MAPS[id].make();
  state.obstacles = m.obstacles;
  state.start = { x: m.start.x, y: m.start.y };
  state.goal = { x: m.goal.x, y: m.goal.y };
  resetRoadmap();
}

function resetRoadmap() {
  state.counter = { checks: 0 };
  state.rng = makeRng(state.seed);
  state.prm = new PRM(state.obstacles, state.radius, state.counter);
  state.phase = 'empty';
  state.queue = [];
  state.gen = null;
  state.acc = 0;
  state.ms = { sample: 0, connect: 0 };
  state.buildChecks = 0;
  state.current = null;
  state.query = null;
  state.queryMs = 0;
  updateComponents();
  setMessage();
}

function updateComponents() {
  const prm = state.prm;
  if (!prm || !prm.nodes.length) {
    state.compColor = null; state.compCount = 0; state.compLargest = 0;
    return;
  }
  const sizes = [...prm.components().entries()].sort((a, b) => b[1] - a[1]);
  const colorOf = new Map();
  sizes.forEach(([root, size], idx) => colorOf.set(root, idx < COMP_COLORS.length && size > 1 ? COMP_COLORS[idx] : '#b3b6bf'));
  state.compColor = (i) => colorOf.get(prm.find(i));
  state.compCount = sizes.length;
  state.compLargest = sizes[0][1];
}

// ---------- fases ----------
function enqueue(...phases) {
  for (const p of phases) if (!state.queue.includes(p)) state.queue.push(p);
}

function request(target) {
  // Encola lo que falte hasta llegar a la fase pedida
  const order = ['sample', 'connect', 'query'];
  const done = { empty: 0, sampling: 0, sampled: 1, connecting: 1, built: 2 }[state.phase];
  const pending = state.gen ? (state.phase === 'sampling' ? 1 : 2) : done;
  for (let i = pending; i <= order.indexOf(target); i++) enqueue(order[i]);
}

function startNext() {
  const next = state.queue.shift();
  if (!next) return;
  if (next === 'sample') {
    state.phase = 'sampling';
    state.gen = state.prm.sampleGen(state.n, state.rng);
  } else if (next === 'connect') {
    state.phase = 'connecting';
    state.gen = state.prm.connectGen(state.k);
  } else if (next === 'query') {
    runQuery();
  }
}

function finishPhase() {
  state.gen = null;
  state.current = null;
  if (state.phase === 'sampling') state.phase = 'sampled';
  else if (state.phase === 'connecting') {
    state.phase = 'built';
    state.buildChecks = state.counter.checks;
  }
  updateComponents();
}

function runQuery() {
  if (state.phase !== 'built') return;
  const before = state.counter.checks;
  const t0 = performance.now();
  state.query = state.prm.query(state.start, state.goal, state.k);
  state.queryMs = performance.now() - t0;
  state.queryChecks = state.counter.checks - before;
  state.counter.checks = before; // las comprobaciones de la consulta se cuentan aparte
}

function advance() {
  if (!state.gen && state.queue.length) startNext();
  if (!state.gen) return;
  const per = SPEED_STEPS[state.speed];
  let steps;
  if (per === Infinity) steps = Infinity;
  else { state.acc += per; steps = Math.floor(state.acc); state.acc -= steps; }
  const key = state.phase === 'sampling' ? 'sample' : 'connect';
  const t0 = performance.now();
  let ev = null, done = false;
  for (let i = 0; i < steps; i++) {
    const r = state.gen.next();
    if (r.done) { done = true; break; }
    ev = r.value;
  }
  state.ms[key] += performance.now() - t0;
  if (ev) state.current = ev;
  if (state.phase === 'connecting') updateComponents();
  if (done) {
    finishPhase();
    if (state.queue.length) startNext();
  }
}

// ---------- textos ----------
const fmt = (v, d = 0) => v.toLocaleString('es-ES', { maximumFractionDigits: d, minimumFractionDigits: d });

function setMessage() {
  const prm = state.prm;
  const msg = $('message');
  let t = '';
  switch (state.phase) {
    case 'empty':
      t = '<b>Construcción, paso 1:</b> se generan configuraciones al azar y solo se guardan las que caen en espacio libre. La zona naranja es la dilatación de los obstáculos por el radio del robot: así el robot se trata como un punto.';
      break;
    case 'sampling':
      t = `<b>Muestreando…</b> ${fmt(prm.nodes.length)} aceptadas de ${fmt(prm.attempts)} intentos. Las cruces rojas cayeron dentro de un obstáculo (dilatado) y se descartan.`;
      break;
    case 'sampled':
      t = `<b>${fmt(prm.nodes.length)} nodos en espacio libre.</b> Paso 2: conectar cada nodo con sus ${state.k} vecinos más cercanos si el segmento entre ellos no choca.`;
      break;
    case 'connecting':
      t = '<b>Conectando…</b> verde: segmento libre, se añade la arista. Rojo: el segmento choca y se descarta.';
      break;
    case 'built': {
      const q = state.query;
      if (!q) {
        t = `<b>Roadmap construido:</b> ${fmt(prm.nodes.length)} nodos, ${fmt(prm.edges.length)} aristas, ${fmt(state.compCount)} componentes conexas. <b>Consulta:</b> unir inicio y objetivo al grafo y buscar el camino más corto (A*).`;
      } else if (q.ok) {
        t = `<b>Camino encontrado</b> (${fmt(q.length)} px). Arrastra el inicio o el objetivo: la consulta se repite en ${fmt(state.queryMs, 2)} ms sin reconstruir el roadmap. Ojo: es el más corto <i>dentro del grafo</i>, no en el espacio libre.`;
      } else {
        t = {
          'start-collision': 'El inicio está dentro de un obstáculo dilatado: muévelo.',
          'goal-collision': 'El objetivo está dentro de un obstáculo dilatado: muévelo.',
          'start-isolated': 'El inicio no ve ningún nodo del roadmap. Prueba con más muestras.',
          'goal-isolated': 'El objetivo no ve ningún nodo del roadmap. Prueba con más muestras.',
          'disconnected': '<b>Sin camino:</b> inicio y objetivo quedan en componentes conexas distintas. Activa «Colorear componentes» para verlo: el roadmap no atraviesa el paso estrecho. Prueba con más muestras.',
        }[q.reason];
      }
      break;
    }
  }
  msg.innerHTML = t;
}

function updateStats() {
  const prm = state.prm;
  const q = state.query;
  const rows = [
    ['Muestras aceptadas', `${fmt(prm.nodes.length)} / ${fmt(prm.attempts)}`],
    ['Aristas', fmt(prm.edges.length)],
    ['Componentes conexas', state.compCount ? `${fmt(state.compCount)} (mayor: ${fmt(state.compLargest)})` : '–'],
    ['Comprobaciones de colisión', fmt(state.counter.checks)],
    ['Tiempo de construcción', state.phase === 'empty' ? '–' : `${fmt(state.ms.sample + state.ms.connect, 1)} ms`],
    ['Tiempo de consulta', q ? `${fmt(state.queryMs, 2)} ms` : '–'],
    ['Longitud del camino', q && q.ok ? `${fmt(q.length)} px` : '–'],
  ];
  $('stats').innerHTML = rows.map(([a, b]) => `<dt>${a}</dt><dd>${b}</dd>`).join('');
}

// ---------- bucle ----------
let lastPhase = null, lastMsgFrame = 0;
function frame() {
  advance();
  drawScene(ctx, state);
  // el mensaje cambia con la fase; durante la animación se refresca de vez en cuando
  lastMsgFrame++;
  if (state.phase !== lastPhase || lastMsgFrame > 6) {
    setMessage();
    lastPhase = state.phase;
    lastMsgFrame = 0;
  }
  updateStats();
  requestAnimationFrame(frame);
}

// ---------- controles ----------
function bindSlider(id, outId, fn, label = (v) => v) {
  const el = $(id), out = $(outId);
  const update = (reset) => {
    const v = +el.value;
    out.textContent = label(v);
    fn(v, reset);
  };
  el.addEventListener('input', () => update(true));
  update(false);
}

function initControls() {
  const sel = $('map');
  sel.innerHTML = Object.entries(POINT_MAPS).map(([k, m]) => `<option value="${k}">${m.name}</option>`).join('');
  sel.value = state.mapId;
  sel.addEventListener('change', () => loadMap(sel.value));

  bindSlider('n', 'nOut', (v, r) => { state.n = v; if (r) resetRoadmap(); });
  bindSlider('k', 'kOut', (v, r) => { state.k = v; if (r) resetRoadmap(); });
  bindSlider('radius', 'rOut', (v, r) => { state.radius = v; if (r) resetRoadmap(); }, (v) => `${v} px`);
  bindSlider('speed', 'speedOut', (v) => { state.speed = v; }, (v) => SPEED_NAMES[v]);

  $('btnSample').addEventListener('click', () => { resetRoadmap(); enqueue('sample'); });
  $('btnConnect').addEventListener('click', () => {
    if (state.phase === 'built' || state.phase === 'connecting') resetRoadmap();
    request('connect');
  });
  $('btnQuery').addEventListener('click', () => {
    if (state.phase === 'built') { runQuery(); setMessage(); } else request('query');
  });
  $('btnAll').addEventListener('click', () => { resetRoadmap(); request('query'); });
  $('btnReset').addEventListener('click', () => resetRoadmap());
  $('btnSeed').addEventListener('click', () => { state.seed++; $('seedOut').textContent = `(${state.seed})`; resetRoadmap(); });
  $('seedOut').textContent = `(${state.seed})`;

  $('chkInflate').addEventListener('change', (e) => { state.show.inflate = e.target.checked; });
  $('chkRejected').addEventListener('change', (e) => { state.show.rejected = e.target.checked; });
  $('chkComps').addEventListener('change', (e) => { state.show.comps = e.target.checked; });
}

// ---------- ratón: mover inicio/objetivo, dibujar y borrar obstáculos ----------
function initPointer() {
  canvas.addEventListener('pointerdown', (e) => {
    const p = toWorld(e);
    canvas.setPointerCapture(e.pointerId);
    if (Math.hypot(p.x - state.start.x, p.y - state.start.y) < 16) state.drag = { kind: 'start' };
    else if (Math.hypot(p.x - state.goal.x, p.y - state.goal.y) < 16) state.drag = { kind: 'goal' };
    else {
      const hit = hitObstacle(p.x, p.y, state.obstacles);
      state.drag = hit >= 0 ? { kind: 'delete', index: hit, x0: p.x, y0: p.y } : { kind: 'draw', x0: p.x, y0: p.y };
    }
  });
  canvas.addEventListener('pointermove', (e) => {
    const d = state.drag;
    const p = toWorld(e);
    if (!d) {
      const over = Math.hypot(p.x - state.start.x, p.y - state.start.y) < 16 || Math.hypot(p.x - state.goal.x, p.y - state.goal.y) < 16;
      canvas.style.cursor = over ? 'grab' : hitObstacle(p.x, p.y, state.obstacles) >= 0 ? 'pointer' : 'crosshair';
      return;
    }
    const cx = Math.min(Math.max(p.x, 0), WORLD_W), cy = Math.min(Math.max(p.y, 0), WORLD_H);
    if (d.kind === 'start' || d.kind === 'goal') {
      state[d.kind] = { x: cx, y: cy };
      if (state.phase === 'built' && state.query) { runQuery(); setMessage(); }
    } else if (d.kind === 'draw') {
      state.draft = { x: Math.min(d.x0, cx), y: Math.min(d.y0, cy), w: Math.abs(cx - d.x0), h: Math.abs(cy - d.y0) };
    } else if (d.kind === 'delete' && Math.hypot(p.x - d.x0, p.y - d.y0) > 5) {
      d.kind = 'none';
    }
  });
  const end = () => {
    const d = state.drag;
    state.drag = null;
    if (!d) return;
    if (d.kind === 'draw' && state.draft && state.draft.w >= 8 && state.draft.h >= 8) {
      const r = state.draft;
      state.obstacles.push({ x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.w), h: Math.round(r.h) });
      resetRoadmap();
    } else if (d.kind === 'delete') {
      state.obstacles.splice(d.index, 1);
      resetRoadmap();
    }
    state.draft = null;
  };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);
}

setupCanvas();
window.addEventListener('resize', setupCanvas);
initControls();
initPointer();
loadMap(state.mapId);
requestAnimationFrame(frame);

// Acceso para depuración desde la consola
window.prmDemo = state;
