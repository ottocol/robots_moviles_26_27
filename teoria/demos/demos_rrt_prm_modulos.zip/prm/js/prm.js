// Probabilistic Roadmap Method
//  - Fase de construcción: muestrear configuraciones libres y conectar vecinos
//  - Fase de consulta: unir inicio y objetivo al grafo y buscar con A*
import { WORLD_W, WORLD_H, pointFree, segmentFree } from './geometry.js';

class MinHeap {
  constructor() { this.a = []; }
  get size() { return this.a.length; }
  push(item, pri) {
    const a = this.a;
    a.push({ item, pri });
    let i = a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (a[p].pri <= a[i].pri) break;
      [a[p], a[i]] = [a[i], a[p]];
      i = p;
    }
  }
  pop() {
    const a = this.a;
    const top = a[0];
    const last = a.pop();
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1;
        let m = i;
        if (l < a.length && a[l].pri < a[m].pri) m = l;
        if (r < a.length && a[r].pri < a[m].pri) m = r;
        if (m === i) break;
        [a[m], a[i]] = [a[i], a[m]];
        i = m;
      }
    }
    return top.item;
  }
}

export class PRM {
  constructor(obstacles, radius, counter) {
    this.obstacles = obstacles;
    this.radius = radius;
    this.counter = counter;
    this.nodes = [];     // {x, y}
    this.adj = [];       // listas de adyacencia
    this.edges = [];     // [i, j] para dibujar
    this.rejected = [];  // muestras que cayeron en obstáculo
    this.attempts = 0;
    this.uf = [];        // union-find para componentes conexas
  }

  isFree(x, y) { return pointFree(x, y, this.radius, this.obstacles, this.counter); }
  segFree(a, b) { return segmentFree(a.x, a.y, b.x, b.y, this.radius, this.obstacles, this.counter); }

  // Paso 1: generar nodos al azar en el espacio libre (muestreo con rechazo)
  *sampleGen(n, rng) {
    const maxAttempts = n * 300;
    while (this.nodes.length < n && this.attempts < maxAttempts) {
      const x = rng() * WORLD_W, y = rng() * WORLD_H;
      this.attempts++;
      if (this.isFree(x, y)) {
        this.nodes.push({ x, y });
        this.adj.push([]);
        this.uf.push(this.nodes.length - 1);
        yield { type: 'accept', x, y };
      } else {
        this.rejected.push({ x, y });
        yield { type: 'reject', x, y };
      }
    }
  }

  // Los k nodos más cercanos a (x, y)
  kNearest(x, y, k, exclude = -1) {
    const best = [];
    for (let i = 0; i < this.nodes.length; i++) {
      if (i === exclude) continue;
      const p = this.nodes[i];
      const d = (p.x - x) ** 2 + (p.y - y) ** 2;
      if (best.length < k || d < best[best.length - 1].d) {
        let j = best.length;
        best.push(null);
        while (j > 0 && best[j - 1].d > d) { best[j] = best[j - 1]; j--; }
        best[j] = { i, d };
        if (best.length > k) best.pop();
      }
    }
    return best;
  }

  // Paso 2: conectar cada nodo con sus k vecinos si el segmento no choca
  *connectGen(k) {
    for (let i = 0; i < this.nodes.length; i++) {
      const a = this.nodes[i];
      const tried = [];
      for (const { i: j } of this.kNearest(a.x, a.y, k, i)) {
        if (this.adj[i].includes(j)) continue;
        const ok = this.segFree(a, this.nodes[j]);
        tried.push({ j, ok });
        if (ok) {
          this.adj[i].push(j);
          this.adj[j].push(i);
          this.edges.push([i, j]);
          this.union(i, j);
        }
      }
      yield { type: 'node', i, tried };
    }
  }

  find(i) {
    while (this.uf[i] !== i) {
      this.uf[i] = this.uf[this.uf[i]];
      i = this.uf[i];
    }
    return i;
  }

  union(a, b) {
    const ra = this.find(a), rb = this.find(b);
    if (ra !== rb) this.uf[ra] = rb;
  }

  // Map raíz -> tamaño de la componente
  components() {
    const size = new Map();
    for (let i = 0; i < this.nodes.length; i++) {
      const r = this.find(i);
      size.set(r, (size.get(r) || 0) + 1);
    }
    return size;
  }

  // Unir un punto externo (inicio u objetivo) a hasta k nodos visibles
  link(p, k) {
    const out = [];
    for (const { i } of this.kNearest(p.x, p.y, k * 3)) {
      if (out.length >= k) break;
      if (this.segFree(p, this.nodes[i])) out.push(i);
    }
    return out;
  }

  // Fase de consulta
  query(start, goal, k) {
    const res = { ok: false, path: null, sLinks: [], gLinks: [], reason: '', length: 0, expanded: 0 };
    if (!this.isFree(start.x, start.y)) { res.reason = 'start-collision'; return res; }
    if (!this.isFree(goal.x, goal.y)) { res.reason = 'goal-collision'; return res; }
    res.sLinks = this.link(start, k);
    res.gLinks = this.link(goal, k);
    const direct = this.segFree(start, goal);
    if (!direct) {
      if (!res.sLinks.length) { res.reason = 'start-isolated'; return res; }
      if (!res.gLinks.length) { res.reason = 'goal-isolated'; return res; }
    }

    const n = this.nodes.length, S = n, G = n + 1;
    const pos = (v) => (v === S ? start : v === G ? goal : this.nodes[v]);
    const gSet = new Set(res.gLinks);
    const neighbors = (v) => {
      if (v === S) { const out = res.sLinks.slice(); if (direct) out.push(G); return out; }
      if (v === G) return [];
      const out = this.adj[v].slice();
      if (gSet.has(v)) out.push(G);
      return out;
    };
    const dist = new Float64Array(n + 2).fill(Infinity);
    const prev = new Int32Array(n + 2).fill(-1);
    const closed = new Uint8Array(n + 2);
    const h = (v) => Math.hypot(pos(v).x - goal.x, pos(v).y - goal.y); // admisible
    const heap = new MinHeap();
    dist[S] = 0;
    heap.push(S, h(S));
    while (heap.size) {
      const v = heap.pop();
      if (closed[v]) continue;
      closed[v] = 1;
      res.expanded++;
      if (v === G) break;
      for (const w of neighbors(v)) {
        const nd = dist[v] + Math.hypot(pos(w).x - pos(v).x, pos(w).y - pos(v).y);
        if (nd < dist[w]) {
          dist[w] = nd;
          prev[w] = v;
          heap.push(w, nd + h(w));
        }
      }
    }
    if (!isFinite(dist[G])) { res.reason = 'disconnected'; return res; }
    const path = [];
    for (let v = G; v !== -1; v = prev[v]) path.push(pos(v));
    path.reverse();
    res.ok = true;
    res.path = path;
    res.length = dist[G];
    return res;
  }
}
