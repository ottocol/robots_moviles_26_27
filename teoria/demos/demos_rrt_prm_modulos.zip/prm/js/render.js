// Dibujo de la escena del PRM
import { WORLD_W, WORLD_H } from './geometry.js';

export const PALETTE = {
  bg: '#fbfbfd', grid: '#eef0f5', obstacle: '#2b2d42', inflate: '#f6dfc6',
  edge: '#a9c4e6', node: '#2f6fb3', rejected: '#e07070', path: '#d4148a',
  start: '#2e9e5b', goal: '#d64545', ok: '#2e9e5b', bad: '#d64545', link: '#8a8f9c',
};

export const COMP_COLORS = ['#2f6fb3', '#d4148a', '#2e9e5b', '#c9761e', '#7b4fc9', '#0f9ba8', '#b5452d', '#6b8e23'];

function drawGrid(ctx) {
  ctx.strokeStyle = PALETTE.grid;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 40; x < WORLD_W; x += 40) { ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, WORLD_H); }
  for (let y = 40; y < WORLD_H; y += 40) { ctx.moveTo(0, y + 0.5); ctx.lineTo(WORLD_W, y + 0.5); }
  ctx.stroke();
}

// Obstáculos y, opcionalmente, su dilatación por el radio del robot
export function drawObstacles(ctx, obstacles, radius, showInflate) {
  if (showInflate && radius > 0) {
    ctx.save();
    ctx.fillStyle = PALETTE.inflate;
    ctx.strokeStyle = PALETTE.inflate;
    ctx.lineJoin = 'round';
    ctx.lineWidth = 2 * radius;
    for (const o of obstacles) {
      ctx.beginPath();
      ctx.rect(o.x, o.y, o.w, o.h);
      ctx.fill();
      ctx.stroke();
    }
    // los bordes del mundo también se dilatan
    ctx.fillRect(0, 0, WORLD_W, radius);
    ctx.fillRect(0, WORLD_H - radius, WORLD_W, radius);
    ctx.fillRect(0, 0, radius, WORLD_H);
    ctx.fillRect(WORLD_W - radius, 0, radius, WORLD_H);
    ctx.restore();
  }
  ctx.fillStyle = PALETTE.obstacle;
  for (const o of obstacles) ctx.fillRect(o.x, o.y, o.w, o.h);
}

function cross(ctx, x, y, s) {
  ctx.moveTo(x - s, y - s); ctx.lineTo(x + s, y + s);
  ctx.moveTo(x - s, y + s); ctx.lineTo(x + s, y - s);
}

function marker(ctx, p, color, label, radius) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.globalAlpha = 0.5;
  ctx.setLineDash([4, 3]);
  ctx.beginPath();
  ctx.arc(p.x, p.y, Math.max(radius, 1), 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
  ctx.fillStyle = color;
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(p.x, p.y, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.font = '600 13px "Avenir Next", Avenir, system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(255,255,255,0.9)';
  ctx.strokeText(label, p.x, p.y - 14);
  ctx.fillText(label, p.x, p.y - 14);
}

export function drawScene(ctx, s) {
  const prm = s.prm;
  ctx.fillStyle = PALETTE.bg;
  ctx.fillRect(0, 0, WORLD_W, WORLD_H);
  drawGrid(ctx);
  drawObstacles(ctx, s.obstacles, s.radius, s.show.inflate);

  if (prm) {
    if (s.show.rejected && prm.rejected.length) {
      ctx.strokeStyle = PALETTE.rejected;
      ctx.lineWidth = 1.2;
      ctx.globalAlpha = 0.6;
      ctx.beginPath();
      for (const p of prm.rejected.slice(-800)) cross(ctx, p.x, p.y, 3);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // aristas
    ctx.lineWidth = 1;
    if (s.show.comps && s.compColor) {
      for (const [i, j] of prm.edges) {
        ctx.strokeStyle = s.compColor(i);
        ctx.globalAlpha = 0.55;
        ctx.beginPath();
        ctx.moveTo(prm.nodes[i].x, prm.nodes[i].y);
        ctx.lineTo(prm.nodes[j].x, prm.nodes[j].y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    } else {
      ctx.strokeStyle = PALETTE.edge;
      ctx.beginPath();
      for (const [i, j] of prm.edges) {
        ctx.moveTo(prm.nodes[i].x, prm.nodes[i].y);
        ctx.lineTo(prm.nodes[j].x, prm.nodes[j].y);
      }
      ctx.stroke();
    }

    // nodos
    for (let i = 0; i < prm.nodes.length; i++) {
      const p = prm.nodes[i];
      ctx.fillStyle = s.show.comps && s.compColor ? s.compColor(i) : PALETTE.node;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // evento actual de la animación
    const ev = s.current;
    if (ev && ev.type === 'accept') {
      ctx.strokeStyle = PALETTE.ok;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(ev.x, ev.y, 9, 0, Math.PI * 2);
      ctx.stroke();
    } else if (ev && ev.type === 'reject') {
      ctx.strokeStyle = PALETTE.bad;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      cross(ctx, ev.x, ev.y, 7);
      ctx.stroke();
    } else if (ev && ev.type === 'node' && prm.nodes[ev.i]) {
      const a = prm.nodes[ev.i];
      ctx.lineWidth = 2.5;
      for (const t of ev.tried) {
        const b = prm.nodes[t.j];
        ctx.strokeStyle = t.ok ? PALETTE.ok : PALETTE.bad;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      ctx.strokeStyle = PALETTE.obstacle;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(a.x, a.y, 8, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  // consulta
  const q = s.query;
  if (q && prm) {
    ctx.save();
    ctx.setLineDash([5, 4]);
    ctx.strokeStyle = PALETTE.link;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (const i of q.sLinks) { ctx.moveTo(s.start.x, s.start.y); ctx.lineTo(prm.nodes[i].x, prm.nodes[i].y); }
    for (const i of q.gLinks) { ctx.moveTo(s.goal.x, s.goal.y); ctx.lineTo(prm.nodes[i].x, prm.nodes[i].y); }
    ctx.stroke();
    ctx.restore();
    if (q.ok) {
      ctx.strokeStyle = PALETTE.path;
      ctx.lineWidth = 4;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      q.path.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.stroke();
    }
  }

  marker(ctx, s.start, PALETTE.start, 'Inicio', s.radius);
  marker(ctx, s.goal, PALETTE.goal, 'Objetivo', s.radius);

  if (s.draft) {
    const d = s.draft;
    ctx.save();
    ctx.fillStyle = 'rgba(43,45,66,0.35)';
    ctx.strokeStyle = PALETTE.obstacle;
    ctx.setLineDash([4, 3]);
    ctx.fillRect(d.x, d.y, d.w, d.h);
    ctx.strokeRect(d.x, d.y, d.w, d.h);
    ctx.restore();
  }
}
