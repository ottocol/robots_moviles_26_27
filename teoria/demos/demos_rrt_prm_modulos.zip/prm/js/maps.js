// Mapas predefinidos. Coordenadas en un mundo de 960 x 600.
import { makeRng } from './rng.js';

const T = 16; // grosor de pared

function rooms() {
  return {
    obstacles: [
      { x: 320, y: 0, w: T, h: 130 }, { x: 320, y: 200, w: T, h: 400 },
      { x: 640, y: 0, w: T, h: 380 }, { x: 640, y: 450, w: T, h: 150 },
      { x: 0, y: 300, w: 230, h: T },
      { x: 656, y: 260, w: 144, h: T }, { x: 880, y: 260, w: 80, h: T },
      { x: 110, y: 420, w: 100, h: 60 }, { x: 430, y: 210, w: 110, h: 150 },
      { x: 760, y: 410, w: 130, h: 50 },
    ],
    start: { x: 70, y: 70, th: 0 },
    goal: { x: 900, y: 540, th: 0 },
  };
}

function narrow() {
  return {
    obstacles: [
      // pasillo de 120 de largo y 40 de ancho
      { x: 420, y: 0, w: 120, h: 280 }, { x: 420, y: 320, w: 120, h: 280 },
      { x: 160, y: 120, w: 120, h: 40 }, { x: 190, y: 400, w: 60, h: 110 },
      { x: 700, y: 90, w: 90, h: 150 }, { x: 650, y: 400, w: 180, h: 40 },
    ],
    start: { x: 100, y: 470, th: 0 },
    goal: { x: 860, y: 130, th: 0 },
  };
}

function forest() {
  const rng = makeRng(11);
  const start = { x: 80, y: 520, th: 0 }, goal = { x: 880, y: 80, th: 0 };
  const obstacles = [];
  while (obstacles.length < 38) {
    const w = 25 + rng() * 45, h = 25 + rng() * 45;
    const x = rng() * (960 - w), y = rng() * (600 - h);
    const cx = x + w / 2, cy = y + h / 2;
    if (Math.hypot(cx - start.x, cy - start.y) < 90 || Math.hypot(cx - goal.x, cy - goal.y) < 90) continue;
    obstacles.push({ x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) });
  }
  return { obstacles, start, goal };
}

// Mapas pensados para el robot rectangular de 84 x 28
function door() {
  return {
    obstacles: [
      { x: 470, y: 0, w: 30, h: 270 }, { x: 470, y: 330, w: 30, h: 270 },
      { x: 200, y: 130, w: 130, h: 60 }, { x: 650, y: 340, w: 60, h: 190 },
    ],
    start: { x: 170, y: 440, th: Math.PI / 2 },
    goal: { x: 800, y: 160, th: Math.PI / 2 },
  };
}

function warehouse() {
  const obstacles = [];
  for (const y of [100, 220, 340, 460]) obstacles.push({ x: 150, y, w: 660, h: 40 });
  return {
    obstacles,
    start: { x: 300, y: 180, th: 0 },
    goal: { x: 650, y: 420, th: Math.PI },
  };
}

export const POINT_MAPS = {
  rooms: { name: 'Habitaciones', make: rooms },
  narrow: { name: 'Paso estrecho', make: narrow },
  forest: { name: 'Bosque de obstáculos', make: forest },
};

export const SE2_MAPS = {
  door: { name: 'Puerta estrecha', make: door },
  warehouse: { name: 'Almacén (dar la vuelta)', make: warehouse },
  rooms: { name: 'Habitaciones', make: rooms },
};
