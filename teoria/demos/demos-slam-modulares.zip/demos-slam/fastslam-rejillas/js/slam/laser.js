import { castRay } from './world.js';

// Láser simulado: 72 haces repartidos en su campo de visión y ruido gaussiano de 3 cm.
// Alcance y campo de visión se eligen en la página (por defecto 5 m y 360°); la
// simulación los fija al empezar con configureLaser().

export const LASER = { beamCount: 72, maxRange: 5, fieldOfView: 2 * Math.PI, rangeNoise: 0.03 };

export function configureLaser({ laserRange, laserFieldOfView }) {
  LASER.maxRange = laserRange;
  LASER.fieldOfView = laserFieldOfView;
}

/** Ángulo del haz i respecto al frente del robot. */
export function beamAngle(i) {
  if (LASER.fieldOfView >= 2 * Math.PI - 1e-9) {
    return -Math.PI + i * 2 * Math.PI / LASER.beamCount;   // vuelta completa, sin repetir el haz de atrás
  }
  return -LASER.fieldOfView / 2 + i * LASER.fieldOfView / (LASER.beamCount - 1);
}

/**
 * Escaneo z_t desde la pose real. Devuelve las distancias y, para cada haz,
 * si ha chocado con algo (hit = 1) o ha llegado al alcance máximo (hit = 0).
 */
export function simulateScan(pose, rng) {
  const ranges = new Float32Array(LASER.beamCount);
  const hit = new Uint8Array(LASER.beamCount);
  for (let i = 0; i < LASER.beamCount; i++) {
    const distance = castRay(pose.x, pose.y, pose.theta + beamAngle(i));
    if (distance < LASER.maxRange) {
      ranges[i] = Math.max(0.05, distance + rng.gaussian() * LASER.rangeNoise);
      hit[i] = 1;
    } else {
      ranges[i] = LASER.maxRange;
    }
  }
  return { ranges, hit };
}

/** Puntos finales de los haces con impacto, vistos desde `pose`: [{ x, y, beam }]. */
export function scanEndpoints(pose, scan) {
  const points = [];
  for (let i = 0; i < LASER.beamCount; i++) {
    if (!scan.hit[i]) continue;
    const angle = pose.theta + beamAngle(i);
    points.push({
      x: pose.x + scan.ranges[i] * Math.cos(angle),
      y: pose.y + scan.ranges[i] * Math.sin(angle),
      beam: i,
    });
  }
  return points;
}
