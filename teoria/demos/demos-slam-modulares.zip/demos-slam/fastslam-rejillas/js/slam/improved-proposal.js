import { DEG, wrapAngle } from './world.js';
import { motionLogDensity, integrateOdometry } from './motion.js';
import { LIKELIHOOD, scanLogLikelihood, hillClimb } from './observation-model.js';

// Propuesta mejorada, como en GMapping (Grisetti et al., 2007). En vez de muestrear
// solo del modelo de movimiento, cada partícula muestrea de
//     τ(x) ∝ p(z | x, m) · p(x | x_{t-1}, u)
// es decir, del producto del láser y la odometría. En un pasillo sin detalles el láser
// no distingue posiciones a lo largo del pasillo y manda la odometría.
//   1. Buscar el máximo de τ por ascenso de colina, partiendo de la odometría.
//   2. Evaluar τ en unos puntos alrededor del máximo.
//   3. Ajustar una gaussiana a esos puntos y muestrear de ella la nueva pose.
//   4. El peso se multiplica por Σ τ(x_k): cuánto encaja el escaneo en el mapa en esa zona.

// Puntos alrededor del máximo: [dx, dy, dθ] en metros y radianes
export const PROPOSAL_OFFSETS = [[0, 0, 0]];
for (const d of [-1, 1]) {
  PROPOSAL_OFFSETS.push([0.05 * d, 0, 0], [0, 0.05 * d, 0], [0, 0, 1 * DEG * d]);
  PROPOSAL_OFFSETS.push([0.035 * d, 0.035 * d, 0], [0.035 * d, -0.035 * d, 0]);
}

/**
 * Nueva pose y log-peso de una partícula con la propuesta mejorada.
 * @param {object} previousPose  pose de la partícula en t−1
 */
export function sampleImprovedProposal(grid, previousPose, u, scan, noiseScale, rng) {
  const expected = integrateOdometry(previousPose, u);
  const logTau = (pose) => LIKELIHOOD.temperature * scanLogLikelihood(grid, pose, scan) +
    motionLogDensity(pose, expected, u, noiseScale);

  const mode = hillClimb(logTau, expected);

  // Puntos alrededor del máximo y su τ (normalizada restando el máximo)
  const points = PROPOSAL_OFFSETS.map(([dx, dy, dt]) =>
    ({ x: mode.x + dx, y: mode.y + dy, theta: wrapAngle(mode.theta + dt) }));
  const logValues = points.map(logTau);
  const maxLog = Math.max(...logValues);
  const tau = logValues.map((v) => Math.exp(v - maxLog));
  const tauSum = tau.reduce((a, b) => a + b, 0);

  // Gaussiana ajustada: media y covarianza ponderadas por τ (en [x, y, θ] relativos al máximo)
  const offsets = points.map((p) => [p.x - mode.x, p.y - mode.y, wrapAngle(p.theta - mode.theta)]);
  const mean = [0, 1, 2].map((k) => offsets.reduce((sum, o, i) => sum + tau[i] * o[k], 0) / tauSum);
  const cov = [0, 1, 2].map((r) => [0, 1, 2].map((c) =>
    offsets.reduce((sum, o, i) => sum + tau[i] * (o[r] - mean[r]) * (o[c] - mean[c]), 0) / tauSum));
  cov[0][0] += 1e-6; cov[1][1] += 1e-6; cov[2][2] += 1e-8;  // que nunca sea singular

  // Muestra x = media + L·n, con L la descomposición de Cholesky de la covarianza
  const L = cholesky3(cov);
  const n = [rng.gaussian(), rng.gaussian(), rng.gaussian()];
  const sample = [0, 1, 2].map((r) => mean[r] + L[r][0] * n[0] + L[r][1] * n[1] + L[r][2] * n[2]);

  return {
    pose: { x: mode.x + sample[0], y: mode.y + sample[1], theta: wrapAngle(mode.theta + sample[2]) },
    logWeight: maxLog + Math.log(tauSum),
  };
}

/** Cholesky de una matriz 3x3 simétrica definida positiva: A = L·Lᵀ. */
export function cholesky3(A) {
  const L = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j <= i; j++) {
      let sum = A[i][j];
      for (let k = 0; k < j; k++) sum -= L[i][k] * L[j][k];
      L[i][j] = i === j ? Math.sqrt(Math.max(sum, 1e-12)) : sum / L[j][j];
    }
  }
  return L;
}
