(function(){
  var DEF_Z = [2.0, 1.8, 3.1];
  var PRESETS = {
    equal:  {w:[1,1,1],   loop:true},
    loop10: {w:[1,1,10],  loop:true},
    odo10:  {w:[10,10,1], loop:true},
    noloop: {w:[1,1,1],   loop:false}
  };
  var state = { z: DEF_Z.slice(), w:[1,1,1], loop:true, x2:0, x3:0, dragging:null };
  var VB_W = 1000, PADX = 72, R = 22, LOOP_Y = 84, AXIS_Y = 196, RULER_Y = 270;
  var svg = document.getElementById('scene');
  var range = {min:-0.45, max:4.45}, frozen = null, anim = null;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function(id){ return document.getElementById(id); };

  function fmt(v, d){
    if (d === undefined) d = 2;
    if (Math.abs(v) < 0.5 * Math.pow(10, -d)) v = 0;
    return v.toLocaleString('es-ES', {minimumFractionDigits:d, maximumFractionDigits:d}).replace('-', '−');
  }
  function fmtS(v, d){
    if (d === undefined) d = 2;
    var s = fmt(v, d);
    return (v >= 0.5 * Math.pow(10, -d) ? '+' : '') + s;
  }
  function fmtW(w){ return w < 9.95 ? fmt(w, 1) : fmt(w, 0); }

  function weights(){ return [state.w[0], state.w[1], state.loop ? state.w[2] : 0]; }
  function solve(){
    var w = weights(), z = state.z;
    var a = w[0] + w[1], b = -w[1], d = w[1] + w[2];
    var r1 = w[0]*z[0] - w[1]*z[1], r2 = w[1]*z[1] + w[2]*z[2];
    var det = a*d - b*b;
    return { x2:(r1*d - b*r2)/det, x3:(a*r2 - b*r1)/det, a:a, b:b, d:d, r1:r1, r2:r2 };
  }
  function resid(x2, x3){ var z = state.z; return [x2 - z[0], x3 - x2 - z[1], x3 - z[2]]; }
  function energy(x2, x3){ var e = resid(x2, x3), w = weights(); return w[0]*e[0]*e[0] + w[1]*e[1]*e[1] + w[2]*e[2]*e[2]; }

  function computeRange(o){
    var z = state.z;
    var vals = [0, z[0], z[0] + z[1], o.x2, o.x3, state.x2, state.x3];
    if (state.loop) vals.push(z[2]);
    var mn = Math.min.apply(null, vals) - 0.45, mx = Math.max.apply(null, vals) + 0.45;
    if (mx - mn < 4.9) mx = mn + 4.9;
    return {min:mn, max:mx};
  }

  function zig(xa, xb, y, amp, coils){
    var L = xb - xa;
    if (L < 34) return 'M' + xa + ',' + y + 'L' + xb + ',' + y;
    var lead = Math.min(14, L * 0.15), body = L - 2*lead, n = coils * 2;
    var d = 'M' + xa.toFixed(1) + ',' + y + 'L' + (xa + lead).toFixed(1) + ',' + y;
    for (var i = 1; i <= n; i++){
      var x = xa + lead + body * (i - 0.5) / n;
      d += 'L' + x.toFixed(1) + ',' + (y + (i % 2 ? -amp : amp));
    }
    d += 'L' + (xb - lead).toFixed(1) + ',' + y + 'L' + xb.toFixed(1) + ',' + y;
    return d;
  }
  function sw(w){ return (1.4 + 1.25 * Math.log2(1 + w)).toFixed(2); }

  function drawScene(o){
    range = state.dragging ? frozen : computeRange(o);
    var X = function(m){ return PADX + (m - range.min) / (range.max - range.min) * (VB_W - 2*PADX); };
    var z = state.z, w = weights(), e = resid(state.x2, state.x3);
    var p1 = X(0), p2 = X(state.x2), p3 = X(state.x3);
    var s = '';

    // Regla
    s += '<line class="ruler" x1="' + (PADX - 36) + '" y1="' + RULER_Y + '" x2="' + (VB_W - PADX + 36) + '" y2="' + RULER_Y + '"/>';
    var step = (range.max - range.min) > 7 ? 1 : 0.5;
    var k0 = Math.ceil(range.min / step), k1 = Math.floor(range.max / step);
    for (var k = k0; k <= k1; k++){
      var t = k * step, x = X(t);
      s += '<line class="ruler" x1="' + x + '" y1="' + RULER_Y + '" x2="' + x + '" y2="' + (RULER_Y - 6) + '"/>';
      s += '<text class="tick" x="' + x + '" y="' + (RULER_Y + 19) + '">' + fmt(t, 1) + '</text>';
    }
    s += '<text class="tick" x="' + (VB_W - 14) + '" y="' + (RULER_Y + 19) + '" style="text-anchor:end">m</text>';
    s += '<line class="track" x1="' + (PADX - 36) + '" y1="' + AXIS_Y + '" x2="' + (VB_W - PADX + 36) + '" y2="' + AXIS_Y + '"/>';

    // Estimaciones fantasma
    s += '<circle class="ghost" cx="' + X(z[0]) + '" cy="' + AXIS_Y + '" r="' + R + '" stroke="var(--odo)" opacity=".75"/>';
    s += '<circle class="ghost" cx="' + X(z[0] + z[1]) + '" cy="' + AXIS_Y + '" r="' + R + '" stroke="var(--odo)" opacity=".75"/>';
    if (state.loop) s += '<circle class="ghost" cx="' + X(z[2]) + '" cy="' + AXIS_Y + '" r="' + R + '" stroke="var(--loop)" opacity=".8"/>';

    // Muelle del cierre de ciclo
    var mid13 = (p1 + p3) / 2;
    s += '<line class="leg" x1="' + p1 + '" y1="' + (AXIS_Y - R) + '" x2="' + p1 + '" y2="' + LOOP_Y + '"/>';
    s += '<line class="leg" x1="' + p3 + '" y1="' + (AXIS_Y - R) + '" x2="' + p3 + '" y2="' + LOOP_Y + '"/>';
    if (state.loop){
      var la = Math.min(p1, p3), lb = Math.max(p1, p3);
      s += '<path class="spring" d="' + zig(la, lb, LOOP_Y, 9, 14) + '" stroke="var(--loop)" stroke-width="' + sw(w[2]) + '"/>';
      s += '<text class="lbl lbl-loop" x="' + mid13 + '" y="' + (LOOP_Y - 24) + '">cierre de ciclo · z₃ = ' + fmt(z[2]) + ' m · e = ' + fmtS(e[2]) + '</text>';
    } else {
      s += '<line x1="' + p1 + '" y1="' + LOOP_Y + '" x2="' + p3 + '" y2="' + LOOP_Y + '" stroke="var(--loop)" stroke-width="1.5" stroke-dasharray="3 6" opacity=".5"/>';
      s += '<text class="lbl lbl-loop" x="' + mid13 + '" y="' + (LOOP_Y - 24) + '" opacity=".7">cierre de ciclo desactivado</text>';
    }

    // Muelles de odometría
    var segs = [[p1, p2, 0], [p2, p3, 1]];
    segs.forEach(function(sg){
      var a = sg[0], b = sg[1], i = sg[2];
      var xa = Math.min(a, b) + R, xb = Math.max(a, b) - R, mid = (a + b) / 2;
      if (xb > xa) s += '<path class="spring" d="' + zig(xa, xb, AXIS_Y, 9, 7) + '" stroke="var(--odo)" stroke-width="' + sw(w[i]) + '"/>';
      s += '<text class="lbl lbl-odo" x="' + mid + '" y="' + (AXIS_Y - 52) + '">z' + (i ? '₂' : '₁') + ' = ' + fmt(z[i]) + ' m</text>';
      s += '<text class="lbl-e" x="' + mid + '" y="' + (AXIS_Y - 32) + '">e = ' + fmtS(e[i]) + '</text>';
    });

    // Anillos del óptimo si el grafo está desajustado
    var off = Math.abs(o.x2 - state.x2) > 0.004 || Math.abs(o.x3 - state.x3) > 0.004;
    if (off && !anim){
      s += '<circle class="ring" cx="' + X(o.x2) + '" cy="' + AXIS_Y + '" r="' + (R + 6) + '"/>';
      s += '<circle class="ring" cx="' + X(o.x3) + '" cy="' + AXIS_Y + '" r="' + (R + 6) + '"/>';
    }

    // Nodos
    s += '<circle class="node-fixed" cx="' + p1 + '" cy="' + AXIS_Y + '" r="' + R + '"/>';
    s += '<text class="node-lbl" x="' + p1 + '" y="' + (AXIS_Y + 6) + '">x₁</text>';
    s += '<text class="val" x="' + p1 + '" y="' + (AXIS_Y + R + 22) + '">0,00</text>';
    s += '<text class="val-sub" x="' + p1 + '" y="' + (AXIS_Y + R + 37) + '">fijo</text>';
    [[p2, 'x2', 'x₂', state.x2], [p3, 'x3', 'x₃', state.x3]].forEach(function(n){
      s += '<circle class="node" cx="' + n[0] + '" cy="' + AXIS_Y + '" r="' + R + '"/>';
      s += '<text class="node-lbl" x="' + n[0] + '" y="' + (AXIS_Y + 6) + '">' + n[2] + '</text>';
      s += '<text class="val" x="' + n[0] + '" y="' + (AXIS_Y + R + 22) + '">' + fmt(n[3]) + '</text>';
    });
    // Zonas de arrastre encima de todo
    s += '<circle class="hit" data-node="x2" cx="' + p2 + '" cy="' + AXIS_Y + '" r="34"/>';
    s += '<circle class="hit" data-node="x3" cx="' + p3 + '" cy="' + AXIS_Y + '" r="34"/>';

    svg.innerHTML = s;
    svg.setAttribute('aria-label', 'Grafo 1D: x₁ = 0, x₂ = ' + fmt(state.x2) + ' m, x₃ = ' + fmt(state.x3) + ' m');
    return off;
  }

  function render(){
    var o = solve();
    var off = drawScene(o);
    var z = state.z, w = weights(), e = resid(state.x2, state.x3);

    $('vx2').textContent = fmt(state.x2);
    $('vx3').textContent = fmt(state.x3);
    $('vF').textContent = fmt(energy(state.x2, state.x3), 3);
    $('vFmin').textContent = off ? '(mínimo posible: ' + fmt(energy(o.x2, o.x3), 3) + ')' : '';
    $('optBtn').disabled = !off || !!anim;
    $('optHint').textContent = anim ? 'Optimizando…' : (off ? 'Desajustado a mano: los anillos verdes marcan el óptimo.' : 'El grafo está en su mínimo.');

    var D = z[0] + z[1] - z[2];
    if (state.loop){
      $('dText').innerHTML = 'La odometría acumulada dice x₃ = <b>' + fmt(z[0] + z[1]) + '</b> y el cierre de ciclo dice <b>' + fmt(z[2]) + '</b>. Discrepan en <b>' + fmt(Math.abs(D)) + ' m</b>, y las tres restricciones se lo reparten:';
    } else {
      $('dText').innerHTML = 'Sin cierre de ciclo no hay nada que contradiga a la odometría: los muelles quedan en su longitud medida y el error es cero.';
    }
    var used = [e[0], e[1], state.loop ? e[2] : 0];
    var tot = Math.abs(used[0]) + Math.abs(used[1]) + Math.abs(used[2]);
    for (var i = 0; i < 3; i++){
      var share = tot > 1e-9 ? Math.abs(used[i]) / tot : 0;
      $('b' + i).style.width = (share * 100).toFixed(1) + '%';
      if (i === 2 && !state.loop){ $('e2').textContent = '—'; $('p2').textContent = ''; }
      else { $('e' + i).textContent = fmtS(used[i]); $('p' + i).textContent = Math.round(share * 100) + ' %'; }
    }

    $('c-loop').classList.toggle('off', !state.loop);
    drawSystem(o);
  }

  function drawSystem(o){
    function cells(arr){ return arr.map(function(v){ return '<span>' + v + '</span>'; }).join(''); }
    $('eq').innerHTML =
      '<span>H =</span><div class="mat c2">' + cells([fmt(o.a), fmt(o.b), fmt(o.b), fmt(o.d)]) + '</div>' +
      '<div class="mat c1 vars">' + cells(['x₂', 'x₃']) + '</div><span>=</span>' +
      '<div class="mat c1">' + cells([fmt(o.r1), fmt(o.r2)]) + '</div>' +
      '<span>→ x₂ = ' + fmt(o.x2) + ', x₃ = ' + fmt(o.x3) + '</span>';
  }

  function syncToOpt(){ var o = solve(); state.x2 = o.x2; state.x3 = o.x3; }
  function cancelAnim(){ if (anim){ cancelAnimationFrame(anim.raf); anim = null; } }
  function animateTo(){
    cancelAnim();
    var o = solve();
    if (reduce){ state.x2 = o.x2; state.x3 = o.x3; render(); return; }
    var from2 = state.x2, from3 = state.x3, t0 = performance.now(), dur = 650;
    anim = {};
    var frame = function(now){
      var k = Math.min(1, (now - t0) / dur), ease = 1 - Math.pow(1 - k, 3);
      state.x2 = from2 + (o.x2 - from2) * ease;
      state.x3 = from3 + (o.x3 - from3) * ease;
      if (k < 1){ render(); anim.raf = requestAnimationFrame(frame); }
      else { anim = null; state.x2 = o.x2; state.x3 = o.x3; render(); }
    };
    anim.raf = requestAnimationFrame(frame);
  }

  function setInputsFromState(){
    for (var i = 0; i < 3; i++){
      $('z' + i).value = state.z[i];
      $('w' + i).value = Math.log10(state.w[i]);
      $('wv' + i).textContent = fmtW(state.w[i]);
    }
    $('loopOn').checked = state.loop;
  }
  function markPreset(){
    var btns = document.querySelectorAll('[data-preset]');
    btns.forEach(function(b){
      var p = PRESETS[b.dataset.preset];
      var match = p.loop === state.loop &&
        state.z.every(function(v, i){ return Math.abs(v - DEF_Z[i]) < 1e-6; }) &&
        p.w.every(function(v, i){ return (!p.loop && i === 2) || Math.abs(v - state.w[i]) / v < 0.01; });
      b.setAttribute('aria-pressed', match ? 'true' : 'false');
    });
  }

  // Controles
  for (var i = 0; i < 3; i++){
    (function(i){
      $('w' + i).addEventListener('input', function(){
        state.w[i] = Math.pow(10, parseFloat(this.value));
        $('wv' + i).textContent = fmtW(state.w[i]);
        cancelAnim(); syncToOpt(); markPreset(); render();
      });
      $('z' + i).addEventListener('input', function(){
        var v = parseFloat(String(this.value).replace(',', '.'));
        if (isNaN(v)) return;
        state.z[i] = v;
        cancelAnim(); syncToOpt(); markPreset(); render();
      });
    })(i);
  }
  $('loopOn').addEventListener('change', function(){
    state.loop = this.checked; markPreset(); animateTo();
  });
  document.querySelectorAll('[data-preset]').forEach(function(b){
    b.addEventListener('click', function(){
      var p = PRESETS[b.dataset.preset];
      state.z = DEF_Z.slice(); state.w = p.w.slice(); state.loop = p.loop;
      setInputsFromState(); markPreset(); animateTo();
    });
  });
  $('optBtn').addEventListener('click', animateTo);

  // Arrastre de nodos
  function toMeters(evt){
    var pt = svg.createSVGPoint(); pt.x = evt.clientX; pt.y = evt.clientY;
    var p = pt.matrixTransform(svg.getScreenCTM().inverse());
    var m = range.min + (p.x - PADX) / (VB_W - 2*PADX) * (range.max - range.min);
    return Math.max(range.min + 0.1, Math.min(range.max - 0.1, m));
  }
  svg.addEventListener('pointerdown', function(evt){
    var t = evt.target.closest ? evt.target.closest('[data-node]') : null;
    if (!t) return;
    cancelAnim();
    state.dragging = t.getAttribute('data-node');
    frozen = {min:range.min, max:range.max};
    svg.classList.add('dragging');
    try { svg.setPointerCapture(evt.pointerId); } catch (err) {}
    evt.preventDefault();
  });
  svg.addEventListener('pointermove', function(evt){
    if (!state.dragging) return;
    state[state.dragging] = toMeters(evt);
    markPreset(); render();
  });
  function endDrag(){
    if (!state.dragging) return;
    state.dragging = null; frozen = null;
    svg.classList.remove('dragging');
    render();
  }
  svg.addEventListener('pointerup', endDrag);
  svg.addEventListener('pointercancel', endDrag);

  setInputsFromState(); syncToOpt(); markPreset(); render();
})();
