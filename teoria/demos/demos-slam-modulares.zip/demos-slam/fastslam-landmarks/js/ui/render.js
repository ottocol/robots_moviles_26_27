import { WORLD, MAP_BOUNDS, START_POSE, LOOP_ROUTE, LANDMARKS } from '../slam/world.js';

// Dibujo en los lienzos. Solo lee la simulación; no la modifica.

/** Colores del tema actual (claro u oscuro), leídos de las variables CSS. */
export function readTheme() {
  const style = getComputedStyle(document.documentElement);
  const get = (name) => style.getPropertyValue(name).trim();
  return {
    background: get('--bg'), panel: get('--panel'), ink: get('--ink'), line: get('--line'),
    muted: get('--muted'), truth: get('--truth'), odometry: get('--odo'),
    particle: get('--particle'), landmark: get('--landmark'), scan: get('--scan'), warn: get('--warn'),
  };
}

/** Paso de metros a píxeles para un lienzo que muestra MAP_BOUNDS entero (y hacia arriba). */
export class Projection {
  constructor(canvas) {
    this.scale = canvas.width / MAP_BOUNDS.width;
  }
  x(x) { return (x - MAP_BOUNDS.x0) * this.scale; }
  y(y) { return (MAP_BOUNDS.y0 + MAP_BOUNDS.height - y) * this.scale; }
}

/** Punto donde cae una observación vista desde `pose`. */
export function observationEndpoint(pose, observation) {
  const angle = pose.theta + observation.bearing;
  return { x: pose.x + observation.range * Math.cos(angle), y: pose.y + observation.range * Math.sin(angle) };
}

// ---------- Primitivas ----------

export function strokePath(ctx, view, points) {
  ctx.beginPath();
  points.forEach((p, k) => {
    if (k === 0) ctx.moveTo(view.x(p.x), view.y(p.y));
    else ctx.lineTo(view.x(p.x), view.y(p.y));
  });
  ctx.stroke();
}

export function drawRobot(ctx, view, pose, color, radius) {
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.beginPath();
  ctx.arc(view.x(pose.x), view.y(pose.y), radius * view.scale, 0, 2 * Math.PI);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(view.x(pose.x), view.y(pose.y));
  ctx.lineTo(view.x(pose.x + Math.cos(pose.theta) * radius * 1.9),
             view.y(pose.y + Math.sin(pose.theta) * radius * 1.9));
  ctx.stroke();
}

/** Flecha de una partícula; la opacidad indica el peso relativo al máximo. */
export function drawParticle(ctx, view, pose, color, opacity) {
  const x = view.x(pose.x);
  const y = view.y(pose.y);
  const a = -pose.theta;  // el eje y del lienzo va hacia abajo
  const length = 9;
  ctx.globalAlpha = opacity;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x + Math.cos(a) * length, y + Math.sin(a) * length);
  ctx.lineTo(x + Math.cos(a + 2.5) * length * 0.6, y + Math.sin(a + 2.5) * length * 0.6);
  ctx.lineTo(x + Math.cos(a - 2.5) * length * 0.6, y + Math.sin(a - 2.5) * length * 0.6);
  ctx.closePath();
  ctx.fill();
  ctx.globalAlpha = 1;
}

/** Landmark real: una cruz. */
export function drawCross(ctx, view, x, y, size, color, width = 2) {
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(view.x(x) - size, view.y(y) - size);
  ctx.lineTo(view.x(x) + size, view.y(y) + size);
  ctx.moveTo(view.x(x) + size, view.y(y) - size);
  ctx.lineTo(view.x(x) - size, view.y(y) + size);
  ctx.stroke();
}

/** Elipse de `sigmas` desviaciones típicas de una covarianza 2x2 [a, b, b, d]. */
export function drawCovarianceEllipse(ctx, view, mean, covariance, sigmas) {
  const [a, b, , d] = covariance;
  const halfTrace = (a + d) / 2;
  const root = Math.sqrt(((a - d) / 2) ** 2 + b * b);
  const major = Math.sqrt(Math.max(halfTrace + root, 0)) * sigmas;
  const minor = Math.sqrt(Math.max(halfTrace - root, 0)) * sigmas;
  const angle = 0.5 * Math.atan2(2 * b, a - d);
  ctx.beginPath();
  ctx.ellipse(view.x(mean[0]), view.y(mean[1]),
    Math.max(major * view.scale, 1.5), Math.max(minor * view.scale, 1.5), -angle, 0, 2 * Math.PI);
}

export function fillWorldBackground(ctx, canvas, view, theme) {
  ctx.fillStyle = theme.background;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = theme.panel;
  ctx.fillRect(view.x(0), view.y(WORLD.height), WORLD.width * view.scale, WORLD.height * view.scale);
}

// ---------- Vistas ----------

/**
 * Mundo real: landmarks, ruta, observaciones, robot real, odometría y todas las partículas.
 * Las observaciones de landmarks que no se veían desde hace tiempo salen en naranja.
 */
export function drawWorldView(canvas, sim, selectedIndex, { showAllTrajectories }, theme) {
  const ctx = canvas.getContext('2d');
  const view = new Projection(canvas);
  const particles = sim.particles;
  const selected = particles[selectedIndex];
  const maxWeight = Math.max(...particles.map((p) => p.weight));
  const { truePose, observations, revisitedIds } = sim.stepData;
  const revisited = new Set(revisitedIds);
  const pastSteps = sim.dataset.steps.slice(0, sim.step + 1);

  fillWorldBackground(ctx, canvas, view, theme);

  // Ruta prevista
  ctx.setLineDash([2, 6]);
  ctx.strokeStyle = theme.muted;
  ctx.lineWidth = 1;
  strokePath(ctx, view, [START_POSE, ...LOOP_ROUTE.map(([x, y]) => ({ x, y }))]);
  ctx.setLineDash([]);

  // Observaciones desde la pose real
  ctx.lineWidth = 1.5;
  for (const observation of observations) {
    const point = observationEndpoint(truePose, observation);
    ctx.strokeStyle = revisited.has(observation.id) ? theme.warn : theme.scan;
    ctx.globalAlpha = revisited.has(observation.id) ? 0.95 : 0.5;
    strokePath(ctx, view, [truePose, point]);
  }
  ctx.globalAlpha = 1;

  // Landmarks reales con su número
  ctx.font = '11px "IBM Plex Mono", monospace';
  ctx.textAlign = 'left';
  for (const landmark of LANDMARKS) {
    drawCross(ctx, view, landmark.x, landmark.y, 5, theme.landmark);
    ctx.fillStyle = theme.muted;
    ctx.fillText(landmark.id, view.x(landmark.x) + 7, view.y(landmark.y) - 5);
  }

  // Árbol de trayectorias: con el tiempo, todas convergen en un antepasado común
  if (showAllTrajectories) {
    ctx.strokeStyle = theme.particle;
    ctx.globalAlpha = Math.max(0.06, 2 / particles.length);
    ctx.lineWidth = 1;
    for (const p of particles) strokePath(ctx, view, p.trajectoryPoints());
    ctx.globalAlpha = 1;
  }

  // Odometría (discontinua) y robot real
  ctx.lineWidth = 2;
  ctx.strokeStyle = theme.odometry;
  ctx.setLineDash([6, 4]);
  strokePath(ctx, view, pastSteps.map((s) => s.odometryPose));
  ctx.setLineDash([]);
  ctx.strokeStyle = theme.truth;
  strokePath(ctx, view, pastSteps.map((s) => s.truePose));
  drawRobot(ctx, view, sim.stepData.odometryPose, theme.odometry, 0.14);
  drawRobot(ctx, view, truePose, theme.truth, 0.18);

  // Partícula seleccionada: su trayectoria y un círculo alrededor
  ctx.strokeStyle = theme.particle;
  ctx.lineWidth = 2;
  strokePath(ctx, view, selected.trajectoryPoints());
  for (const p of particles) {
    drawParticle(ctx, view, p.pose, theme.particle, 0.12 + 0.88 * p.weight / maxWeight);
  }
  ctx.strokeStyle = theme.ink;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(view.x(selected.pose.x), view.y(selected.pose.y), 13, 0, 2 * Math.PI);
  ctx.stroke();
}

/**
 * Mapa de una partícula: sus landmarks (media y elipse de 2σ), su trayectoria y las
 * observaciones del paso actual vistas desde SU pose. Tras la corrección, una línea une
 * cada observación con el landmark al que se ha asociado.
 */
export function drawParticleMap(canvas, sim, particle, { showRealLandmarks, showAllLandmarks, ellipseScale }, theme) {
  const ctx = canvas.getContext('2d');
  const view = new Projection(canvas);
  const { observations, revisitedIds } = sim.stepData;
  const revisited = new Set(revisitedIds);
  const corrected = sim.phase !== 'prediction';  // en la predicción aún no hay asociaciones

  fillWorldBackground(ctx, canvas, view, theme);

  if (showRealLandmarks) {
    for (const landmark of LANDMARKS) drawCross(ctx, view, landmark.x, landmark.y, 5, theme.muted, 1.5);
  }

  // Landmarks de TODAS las partículas: su dispersión es la incertidumbre real del mapa
  if (showAllLandmarks) {
    ctx.fillStyle = theme.muted;
    ctx.globalAlpha = Math.max(0.15, Math.min(0.6, 8 / sim.particles.length));
    for (const other of sim.particles) {
      for (const landmark of other.landmarks) {
        ctx.fillRect(view.x(landmark.mean[0]) - 1.5, view.y(landmark.mean[1]) - 1.5, 3, 3);
      }
    }
    ctx.globalAlpha = 1;
  }

  ctx.strokeStyle = theme.particle;
  ctx.globalAlpha = 0.6;
  ctx.lineWidth = 2;
  strokePath(ctx, view, particle.trajectoryPoints());
  ctx.globalAlpha = 1;

  // Landmarks del mapa de la partícula
  const updatedThisStep = new Set(corrected ? particle.associations.map((a) => a.landmarkIndex) : []);
  particle.landmarks.forEach((landmark, j) => {
    // Elipse de 2σ, agrandada `ellipseScale` veces para que se vea
    drawCovarianceEllipse(ctx, view, landmark.mean, landmark.covariance, 2 * ellipseScale);
    ctx.fillStyle = theme.particle;
    ctx.globalAlpha = 0.15;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = theme.particle;
    ctx.lineWidth = updatedThisStep.has(j) ? 2 : 1;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(view.x(landmark.mean[0]), view.y(landmark.mean[1]), 2.5, 0, 2 * Math.PI);
    ctx.fill();
  });

  // Observaciones del paso actual desde la pose de la partícula
  observations.forEach((observation, k) => {
    const point = observationEndpoint(particle.pose, observation);
    const color = revisited.has(observation.id) ? theme.warn : theme.scan;
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.35;
    ctx.lineWidth = 1;
    strokePath(ctx, view, [particle.pose, point]);
    ctx.globalAlpha = 1;

    const association = corrected ? particle.associations[k] : null;
    if (association && !association.isNew) {
      const landmark = particle.landmarks[association.landmarkIndex];
      ctx.setLineDash([3, 3]);
      ctx.strokeStyle = theme.ink;
      ctx.lineWidth = 1.5;
      strokePath(ctx, view, [point, { x: landmark.mean[0], y: landmark.mean[1] }]);
      ctx.setLineDash([]);
    }
    ctx.fillStyle = color;
    ctx.fillRect(view.x(point.x) - 3.5, view.y(point.y) - 3.5, 7, 7);
    if (association && association.isNew) {
      ctx.strokeStyle = theme.warn;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(view.x(point.x), view.y(point.y), 10, 0, 2 * Math.PI);
      ctx.stroke();
    }
  });

  drawRobot(ctx, view, particle.pose, theme.particle, 0.16);
}

/** Miniatura del mapa de una partícula: landmarks, trayectoria y pose. */
export function drawThumbnail(canvas, particle, theme) {
  const ctx = canvas.getContext('2d');
  const view = new Projection(canvas);
  fillWorldBackground(ctx, canvas, view, theme);
  ctx.strokeStyle = theme.particle;
  ctx.globalAlpha = 0.45;
  ctx.lineWidth = 1;
  strokePath(ctx, view, particle.trajectoryPoints());
  ctx.globalAlpha = 1;
  ctx.fillStyle = theme.ink;
  for (const landmark of particle.landmarks) {
    ctx.fillRect(view.x(landmark.mean[0]) - 1.5, view.y(landmark.mean[1]) - 1.5, 3, 3);
  }
  ctx.fillStyle = theme.particle;
  ctx.beginPath();
  ctx.arc(view.x(particle.pose.x), view.y(particle.pose.y), 3, 0, 2 * Math.PI);
  ctx.fill();
}

/** Gráfica de Neff/N con el umbral N/2, las marcas de remuestreo y el paso del cierre. */
export function drawNeffChart(canvas, sim, theme) {
  const ctx = canvas.getContext('2d');
  const { width, height } = canvas;
  const history = sim.neffHistory;
  const span = sim.dataset.lastStep;
  const px = (step) => 4 + (width - 8) * step / span;
  const py = (ratio) => height - 6 - (height - 12) * ratio;

  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = theme.line;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (const ratio of [0, 1]) {
    ctx.moveTo(0, py(ratio));
    ctx.lineTo(width, py(ratio));
  }
  ctx.stroke();

  ctx.setLineDash([5, 4]);
  ctx.strokeStyle = theme.muted;
  ctx.beginPath();
  ctx.moveTo(0, py(0.5));
  ctx.lineTo(width, py(0.5));
  ctx.stroke();
  ctx.setLineDash([]);

  if (sim.dataset.closureStep > 0) {
    ctx.strokeStyle = theme.warn;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px(sim.dataset.closureStep), 0);
    ctx.lineTo(px(sim.dataset.closureStep), height);
    ctx.stroke();
  }
  ctx.fillStyle = theme.muted;
  for (const step of sim.resampleSteps) ctx.fillRect(px(step) - 0.5, height - 5, 1.5, 5);

  ctx.strokeStyle = theme.particle;
  ctx.lineWidth = 2;
  ctx.beginPath();
  history.forEach((ratio, step) => {
    if (step === 0) ctx.moveTo(px(step), py(ratio));
    else ctx.lineTo(px(step), py(ratio));
  });
  ctx.stroke();
}
