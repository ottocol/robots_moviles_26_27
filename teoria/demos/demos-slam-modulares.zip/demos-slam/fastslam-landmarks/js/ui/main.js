import { DEG, wrapAngle } from '../slam/geometry.js';
import { MAP_BOUNDS, LANDMARKS } from '../slam/world.js';
import { generateDataset } from '../slam/dataset.js';
import { Simulation } from '../slam/simulation.js';
import { readTheme, drawWorldView, drawParticleMap, drawThumbnail, drawNeffChart } from './render.js';

// Interfaz: controles, estado de la página y orquestación del dibujo.

const $ = (id) => document.getElementById(id);

const THUMBNAIL_INTERVAL_MS = 300;    // refresco de miniaturas mientras se reproduce
const NOTE_DURATION_STEPS = 15;       // pasos que se muestra un aviso de linaje

const PHASE_NAMES = {
  start: 'inicio', prediction: 'predicción', correction: 'corrección', resampling: 'remuestreo',
};

const controls = {
  worldCanvas: $('worldCanvas'), mapCanvas: $('mapCanvas'), neffCanvas: $('neffCanvas'),
  thumbnails: $('thumbnails'),
  toStart: $('toStart'), backStep: $('backStep'), backPhase: $('backPhase'),
  play: $('play'), forwardPhase: $('forwardPhase'), forwardStep: $('forwardStep'),
  timeline: $('timeline'), closureMark: $('closureMark'), positionLabel: $('positionLabel'),
  speed: $('speed'), speedValue: $('speedValue'),
  pauseBeforeClosure: $('pauseBeforeClosure'), goToClosure: $('goToClosure'),
  particleCount: $('particleCount'), association: $('association'), seed: $('seed'),
  randomSeed: $('randomSeed'), motionNoise: $('motionNoise'), motionNoiseValue: $('motionNoiseValue'),
  sensorRange: $('sensorRange'), sensorBearing: $('sensorBearing'), matchR: $('matchR'),
  filterRange: $('filterRange'), filterBearing: $('filterBearing'),
  followBest: $('followBest'), showAllTrajectories: $('showAllTrajectories'),
  showRealLandmarks: $('showRealLandmarks'), showAllLandmarks: $('showAllLandmarks'),
  ellipseScale: $('ellipseScale'), ellipseLegend: $('ellipseLegend'),
  algorithm: $('algorithm'), banner: $('banner'), bannerText: $('bannerText'),
  worldInfo: $('worldInfo'), mapInfo: $('mapInfo'),
  stats: {
    step: $('statStep'), neff: $('statNeff'), resamples: $('statResamples'),
    landmarksCopied: $('statLandmarksCopied'), landmarks: $('statLandmarks'),
    poseError: $('statPoseError'), mapError: $('statMapError'), odometryError: $('statOdometryError'),
    sigma: $('statSigma'),
  },
};

const state = {
  dataset: null,
  sim: null,
  selected: 0,           // casilla de la partícula que se ve en grande
  note: null,            // aviso de linaje: { text, step }
  playing: false,
  timer: null,
  lastThumbnailDraw: 0,
};

// ---------- Ciclo de vida de la simulación ----------

// R «ajustada»: el filtro supone un 50 % más de ruido que el real, para no confiar de más
const R_MARGIN = 1.5;

/** Ruido real del sensor simulado (sliders en cm y grados). */
function readSensorNoise() {
  return {
    range: Number(controls.sensorRange.value) / 100,
    bearing: Number(controls.sensorBearing.value) * DEG,
  };
}

/** R del filtro. Si está ajustada al sensor, los sliders de R siguen al ruido real. */
function readMeasurementNoise() {
  if (controls.matchR.checked) {
    controls.filterRange.value = Number(controls.sensorRange.value) * R_MARGIN;
    controls.filterBearing.value = Number(controls.sensorBearing.value) * R_MARGIN;
  }
  return {
    range: Number(controls.filterRange.value) / 100,
    bearing: Number(controls.filterBearing.value) * DEG,
  };
}

/** Muestra los valores de los sliders del sensor junto a cada uno. */
function updateNoiseLabels() {
  readMeasurementNoise();
  for (const slider of [controls.sensorRange, controls.filterRange]) {
    $(slider.id + 'Value').textContent = `${Number(slider.value).toFixed(0)} cm`;
  }
  for (const slider of [controls.sensorBearing, controls.filterBearing]) {
    $(slider.id + 'Value').textContent = `${Number(slider.value).toFixed(1).replace('.', ',')}°`;
  }
  controls.filterRange.disabled = controls.filterBearing.disabled = controls.matchR.checked;
}

function readConfig() {
  const seed = Math.abs(Math.floor(Number(controls.seed.value))) || 0;
  controls.seed.value = seed;
  return {
    seed,
    particleCount: Number(controls.particleCount.value),
    association: controls.association.value,
    motionNoise: Number(controls.motionNoise.value),
    measurementNoise: readMeasurementNoise(),
  };
}

/** Semilla nueva: otro recorrido del robot. Vuelve al principio. */
function restart() {
  stop();
  const config = readConfig();
  state.dataset = generateDataset(config.seed, readSensorNoise());
  state.sim = new Simulation(state.dataset, config);
  state.selected = 0;
  state.note = null;
  buildThumbnails();
  configureTimeline();
  render({ thumbnails: true });
}

/**
 * Ajustes nuevos sobre el MISMO recorrido: se rehace el filtro hasta la posición actual.
 * Sirve para comparar, por ejemplo, la asociación en pleno cierre. Si cambia el ruido
 * real del sensor, se regeneran las medidas: el camino del robot no cambia.
 */
function rerunFilter({ newMeasurements = false } = {}) {
  stop();
  const position = state.sim.position;
  if (newMeasurements) state.dataset = generateDataset(state.sim.config.seed, readSensorNoise());
  const countChanged = Number(controls.particleCount.value) !== state.sim.filter.count;
  state.sim = new Simulation(state.dataset, readConfig());
  state.sim.goTo(position);
  state.note = null;
  if (countChanged) {
    state.selected = 0;
    buildThumbnails();
  }
  render({ thumbnails: true });
}

/** Avanza fase a fase hasta `target`; si se remuestrea, sigue el linaje elegido. */
function advanceTo(target) {
  const sim = state.sim;
  while (sim.position < target && sim.advancePhase()) {
    if (sim.phase === 'resampling' && sim.lastResample.resampled) followLineage();
  }
}

/** Mueve la línea de tiempo a `position`, hacia delante o hacia atrás. */
function goTo(position) {
  if (position > state.sim.position) {
    advanceTo(position);
  } else {
    state.sim.goTo(position);
    state.note = null;
  }
}

/**
 * Siguiente posición al avanzar: una fase o hasta el final del paso. Si por el camino
 * está el cierre de ciclo y la pausa está activada, se para justo antes de corregir.
 */
function nextPosition(wholeStep) {
  const sim = state.sim;
  let target = wholeStep ? 3 * (sim.step + (sim.position % 3 === 0 ? 1 : 0)) : sim.position + 1;
  const closure = sim.closurePosition;
  if (controls.pauseBeforeClosure.checked && closure > sim.position && closure < target) target = closure;
  return Math.min(target, sim.lastPosition);
}

function previousPosition(wholeStep) {
  const sim = state.sim;
  if (!wholeStep) return Math.max(0, sim.position - 1);
  const intoStep = sim.position % 3;
  return Math.max(0, sim.position - (intoStep === 0 ? 3 : intoStep));
}

function move(position) {
  stop();
  goTo(position);
  render({ thumbnails: true });
}

function tick() {
  if (!state.playing) return;
  const sim = state.sim;
  goTo(nextPosition(true));
  if (sim.position === sim.lastPosition || sim.position === sim.closurePosition) stop();
  render();
  if (state.playing) state.timer = setTimeout(tick, 1000 / Number(controls.speed.value));
}

function play() {
  if (state.sim.position >= state.sim.lastPosition) return;
  state.playing = true;
  tick();
}

function stop() {
  state.playing = false;
  clearTimeout(state.timer);
  if (state.sim) updateButtons();
}

// ---------- Selección de partícula ----------

function selectParticle(index) {
  state.selected = index;
  state.note = null;
  controls.followBest.checked = false;
  render({ thumbnails: true });
}

/**
 * El número de una partícula es solo su casilla: tras remuestrear, la casilla
 * contiene otra partícula. Para seguir a «la misma», pasamos a una de sus hijas.
 */
function followLineage() {
  if (controls.followBest.checked) return;
  const step = state.sim.step;
  const children = [];
  state.sim.particles.forEach((p, i) => {
    if (p.parentIndex === state.selected) children.push(i);
  });
  if (children.length) {
    state.note = { text: `linaje seguido (${children.length} ${children.length > 1 ? 'hijas' : 'hija'})`, step };
    state.selected = children[0];
  } else {
    state.note = { text: `el linaje de #${state.selected} se extinguió en el paso ${step}`, step };
    controls.followBest.checked = true;
  }
}

/** Partícula más cercana a un clic en el mundo (a menos de 60 cm). */
function particleAt(event) {
  const rect = controls.worldCanvas.getBoundingClientRect();
  const x = MAP_BOUNDS.x0 + (event.clientX - rect.left) / rect.width * MAP_BOUNDS.width;
  const y = MAP_BOUNDS.y0 + MAP_BOUNDS.height - (event.clientY - rect.top) / rect.height * MAP_BOUNDS.height;
  let nearest = -1;
  let nearestDistance = 0.6;
  state.sim.particles.forEach((p, i) => {
    const d = Math.hypot(p.pose.x - x, p.pose.y - y);
    if (d < nearestDistance) {
      nearestDistance = d;
      nearest = i;
    }
  });
  return nearest;
}

// ---------- Dibujo y textos ----------

function render({ thumbnails = false } = {}) {
  const sim = state.sim;
  const theme = readTheme();
  if (controls.followBest.checked) state.selected = sim.filter.bestIndex();
  if (state.selected >= sim.particles.length) state.selected = 0;
  const particle = sim.particles[state.selected];

  drawWorldView(controls.worldCanvas, sim, state.selected,
    { showAllTrajectories: controls.showAllTrajectories.checked }, theme);
  drawParticleMap(controls.mapCanvas, sim, particle,
    {
      showRealLandmarks: controls.showRealLandmarks.checked,
      showAllLandmarks: controls.showAllLandmarks.checked,
      ellipseScale: Number(controls.ellipseScale.value),
    }, theme);
  const scale = Number(controls.ellipseScale.value);
  controls.ellipseLegend.textContent = scale > 1 ? `elipse de 2σ aumentada ×${scale}` : 'elipse de 2σ (tamaño real)';
  drawNeffChart(controls.neffCanvas, sim, theme);
  updateStats(particle);
  updateHeaders(particle);
  updateAlgorithm();
  updateBanner();
  updateButtons();

  const now = performance.now();
  if (thumbnails || !state.playing || now - state.lastThumbnailDraw > THUMBNAIL_INTERVAL_MS) {
    updateThumbnails(theme);
    state.lastThumbnailDraw = now;
  }
}

function formatPoseError(pose, truth) {
  const distance = Math.hypot(pose.x - truth.x, pose.y - truth.y);
  const angle = Math.abs(wrapAngle(pose.theta - truth.theta)) / DEG;
  return `${distance.toFixed(2)} m · ${angle.toFixed(1)}°`;
}

/** Error medio del mapa: distancia de cada landmark estimado al real que lo originó. */
function mapError(particle) {
  if (!particle.landmarks.length) return '–';
  let total = 0;
  for (const l of particle.landmarks) {
    const real = LANDMARKS[l.sourceId];
    total += Math.hypot(l.mean[0] - real.x, l.mean[1] - real.y);
  }
  return `${(total / particle.landmarks.length).toFixed(2)} m`;
}

/** Mediana de la desviación típica (eje mayor) de los landmarks de una partícula. */
function medianLandmarkSigma(particle) {
  if (!particle.landmarks.length) return '–';
  const sigmas = particle.landmarks.map(({ covariance: [a, b, , d] }) =>
    Math.sqrt((a + d) / 2 + Math.sqrt(((a - d) / 2) ** 2 + b * b)));
  sigmas.sort((x, y) => x - y);
  return `${(sigmas[sigmas.length >> 1] * 100).toFixed(1).replace('.', ',')} cm`;
}

function updateStats(particle) {
  const sim = state.sim;
  const s = controls.stats;
  const truth = sim.stepData.truePose;
  const distinct = new Set(particle.landmarks.map((l) => l.sourceId)).size;
  const duplicates = particle.landmarks.length - distinct;
  s.step.textContent = `${sim.step} / ${sim.dataset.lastStep}`;
  s.neff.textContent = `${sim.filter.effectiveSampleSize().toFixed(1)} / ${sim.particles.length}`;
  s.resamples.textContent = sim.resampleSteps.length;
  s.landmarksCopied.textContent = sim.landmarksCopied.toLocaleString('es');
  s.landmarks.textContent = duplicates ? `${particle.landmarks.length} (${duplicates} dupl.)` : particle.landmarks.length;
  s.poseError.textContent = formatPoseError(particle.pose, truth);
  s.mapError.textContent = mapError(particle);
  s.odometryError.textContent = formatPoseError(sim.stepData.odometryPose, truth);
  s.sigma.textContent = medianLandmarkSigma(particle);
}

function updateHeaders(particle) {
  const sim = state.sim;
  const i = state.selected;
  const closure = sim.dataset.closureStep;

  if (sim.step === closure) controls.worldInfo.textContent = 'cierre de ciclo';
  else if (closure > 0 && sim.step > closure) controls.worldInfo.textContent = `ciclo cerrado en el paso ${closure}`;
  else controls.worldInfo.textContent = '';

  const parts = [`${controls.followBest.checked ? 'mejor: ' : ''}#${i}`];
  let weight = `peso ${(particle.weight * 100).toFixed(1)} %`;
  if (sim.phase === 'correction') weight = `peso ${(particle.weightBeforeCorrection * 100).toFixed(1)} → ${(particle.weight * 100).toFixed(1)} %`;
  parts.push(weight);
  if (sim.phase === 'resampling' && sim.lastResample.resampled) parts.push(`copia de #${particle.parentIndex}`);
  if (state.note && sim.step - state.note.step < NOTE_DURATION_STEPS) parts.push(state.note.text);
  controls.mapInfo.textContent = parts.join(' · ');
}

/** Resalta en el pseudocódigo la fase que se acaba de aplicar. */
function updateAlgorithm() {
  const sim = state.sim;
  for (const item of controls.algorithm.children) {
    item.classList.toggle('current', item.dataset.phase === sim.phase);
  }
  const resampleItem = controls.algorithm.querySelector('[data-phase="resampling"] .result');
  if (sim.phase === 'resampling') {
    resampleItem.textContent = sim.lastResample.resampled
      ? '→ se ha remuestreado' : '→ Neff ≥ N/2: no hace falta';
  } else {
    resampleItem.textContent = '';
  }
}

/** Explicación del cierre de ciclo, adaptada a la fase en la que estamos. */
function updateBanner() {
  const sim = state.sim;
  const inClosure = sim.step === sim.dataset.closureStep && sim.phase !== 'start';
  controls.banner.hidden = !inClosure;
  if (!inClosure) return;
  const ids = sim.stepData.revisitedIds.join(', ');
  const texts = {
    prediction:
      `Paso ${sim.step}: el robot vuelve a ver el landmark ${ids}, que no veía desde el principio ` +
      '(en naranja). Las partículas ya se han movido, pero todavía no se han corregido. Pincha en ' +
      'varias miniaturas: en el mapa de cada partícula, el cuadrado naranja es la observación vista ' +
      'desde su pose. Unas lo ven caer sobre el landmark que mapearon al principio y otras lejos. ' +
      'Pulsa «Fase ▶» para corregir.',
    correction:
      'Corrección: cada partícula ha multiplicado su peso por lo bien que encaja la observación con ' +
      `su mapa. Neff ha caído a ${sim.filter.effectiveSampleSize().toFixed(1)}. En las miniaturas, ` +
      '▲ y ▼ indican qué partículas han ganado o perdido peso. Pulsa «Fase ▶» para remuestrear.',
    resampling:
      'Remuestreo: sobreviven las partículas cuya trayectoria es compatible con el cierre, y con ' +
      'ellas sus mapas. El cierre dura varios pasos más, mientras se ven más landmarks antiguos: ' +
      'sigue avanzando y mira el error de pose y la gráfica de Neff. Prueba también a volver atrás ' +
      'y cambiar la asociación de datos.',
  };
  controls.bannerText.textContent = texts[sim.phase];
}

function updateButtons() {
  const sim = state.sim;
  const atStart = sim.position === 0;
  const atEnd = sim.position >= sim.lastPosition;
  controls.toStart.disabled = controls.backStep.disabled = controls.backPhase.disabled = atStart;
  controls.forwardPhase.disabled = controls.forwardStep.disabled = atEnd;
  controls.play.disabled = atEnd;
  if (atEnd) controls.play.textContent = 'Ruta terminada';
  else if (state.playing) controls.play.textContent = '⏸ Pausar';
  else controls.play.textContent = sim.position > 0 ? '▶ Seguir' : '▶ Recorrer el ciclo';

  controls.timeline.value = sim.position;
  controls.positionLabel.textContent = `paso ${sim.step} · ${PHASE_NAMES[sim.phase]}`;
}

/** Ajusta la línea de tiempo al recorrido y coloca la marca del cierre de ciclo. */
function configureTimeline() {
  const sim = state.sim;
  controls.timeline.max = sim.lastPosition;
  const closure = sim.closurePosition;
  controls.closureMark.hidden = closure < 0;
  controls.goToClosure.disabled = closure < 0;
  controls.closureMark.style.left = `calc(${closure / sim.lastPosition} * (100% - 16px) + 8px)`;
}

// ---------- Miniaturas ----------

function buildThumbnails() {
  controls.thumbnails.textContent = '';
  state.sim.particles.forEach((_, i) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'thumb';
    button.innerHTML =
      '<canvas width="108" height="84"></canvas>' +
      '<div class="weight-bar"><i></i></div>' +
      `<small><span>#${i}</span><span class="weight"></span></small>`;
    button.addEventListener('click', () => selectParticle(i));
    controls.thumbnails.appendChild(button);
  });
}

function updateThumbnails(theme) {
  const sim = state.sim;
  const best = sim.filter.bestIndex();
  const maxWeight = Math.max(...sim.particles.map((p) => p.weight));
  [...controls.thumbnails.children].forEach((button, i) => {
    const particle = sim.particles[i];
    drawThumbnail(button.querySelector('canvas'), particle, theme);
    button.querySelector('.weight-bar i').style.width = `${(100 * particle.weight / maxWeight).toFixed(0)}%`;
    let trend = '';
    if (sim.phase === 'correction') {
      const ratio = particle.weight / particle.weightBeforeCorrection;
      if (ratio > 1.5) trend = '▲';
      else if (ratio < 0.67) trend = '▼';
    }
    const label = button.querySelector('.weight');
    label.textContent = `${i === best ? '★ ' : ''}${trend}${(particle.weight * 100).toFixed(1)}%`;
    label.dataset.trend = trend;
    button.classList.toggle('selected', i === state.selected);
  });
}

// ---------- Eventos ----------

controls.toStart.addEventListener('click', () => move(0));
controls.backStep.addEventListener('click', () => move(previousPosition(true)));
controls.backPhase.addEventListener('click', () => move(previousPosition(false)));
controls.forwardPhase.addEventListener('click', () => move(nextPosition(false)));
controls.forwardStep.addEventListener('click', () => move(nextPosition(true)));
controls.goToClosure.addEventListener('click', () => move(state.sim.closurePosition));
controls.play.addEventListener('click', () => (state.playing ? stop() : play()));

// Arrastrar la línea de tiempo: se dibuja como mucho una vez por fotograma
let pendingTimelinePosition = null;
controls.timeline.addEventListener('input', () => {
  stop();
  if (pendingTimelinePosition === null) {
    requestAnimationFrame(() => {
      goTo(pendingTimelinePosition);
      pendingTimelinePosition = null;
      render({ thumbnails: true });
    });
  }
  pendingTimelinePosition = Number(controls.timeline.value);
});

controls.seed.addEventListener('change', restart);
controls.randomSeed.addEventListener('click', () => {
  controls.seed.value = Math.floor(Math.random() * 100000);
  restart();
});
for (const input of [controls.particleCount, controls.association, controls.motionNoise,
                     controls.filterRange, controls.filterBearing, controls.matchR]) {
  input.addEventListener('change', () => rerunFilter());
}
for (const input of [controls.sensorRange, controls.sensorBearing]) {
  input.addEventListener('change', () => rerunFilter({ newMeasurements: true }));
}
for (const input of [controls.sensorRange, controls.sensorBearing, controls.filterRange,
                     controls.filterBearing, controls.matchR]) {
  input.addEventListener('input', updateNoiseLabels);
}
controls.motionNoise.addEventListener('input', () => {
  controls.motionNoiseValue.textContent = controls.motionNoise.value;
});
controls.speed.addEventListener('input', () => {
  controls.speedValue.textContent = controls.speed.value;
});
for (const box of [controls.followBest, controls.showAllTrajectories, controls.showRealLandmarks,
                   controls.showAllLandmarks, controls.ellipseScale]) {
  box.addEventListener('change', () => {
    state.note = null;
    render({ thumbnails: true });
  });
}
controls.worldCanvas.addEventListener('click', (event) => {
  const index = particleAt(event);
  if (index >= 0) selectParticle(index);
});

document.addEventListener('keydown', (event) => {
  const tag = event.target.tagName;
  if (tag === 'SELECT' || tag === 'INPUT') return;
  const actions = {
    ArrowRight: () => move(nextPosition(event.shiftKey)),
    ArrowLeft: () => move(previousPosition(event.shiftKey)),
    Home: () => move(0),
    ' ': () => (state.playing ? stop() : play()),
  };
  if (actions[event.key]) {
    event.preventDefault();
    actions[event.key]();
  }
});

// Redibujar si cambia el tema claro/oscuro
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => render({ thumbnails: true }));
new MutationObserver(() => render({ thumbnails: true }))
  .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

updateNoiseLabels();
restart();
