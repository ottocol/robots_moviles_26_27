import { Mat2 } from './geometry.js';
import { SENSOR, sampleMotionModel } from './robot.js';
import { measurementCovariance, Landmark } from './landmark-ekf.js';

// FastSLAM 1.0 con landmarks: cada partícula es una hipótesis de trayectoria con
// su propio mapa, formado por un EKF de 2x2 por landmark.

// Asociación por máxima verosimilitud: si la mejor candidata está a más de esta
// distancia de Mahalanobis² (99 % de una χ² con 2 grados de libertad), es un landmark nuevo.
export const ASSOCIATION_GATE = 9.21;


/**
 * Una partícula: pose actual, peso, mapa (vector de landmarks) y trayectoria.
 * La trayectoria es una lista enlazada hacia atrás ({ x, y, previous }), así que
 * las copias de una misma madre comparten todo el tramo anterior al remuestreo.
 */
export class Particle {
  constructor({ pose, weight, landmarks, trajectory, parentIndex = -1, associations = [] }) {
    this.pose = pose;
    this.weight = weight;
    this.landmarks = landmarks;
    this.trajectory = trajectory;
    this.parentIndex = parentIndex;      // casilla de la madre en la generación anterior
    this.associations = associations;    // última corrección: [{ observation, landmarkIndex, isNew }]
    this.weightBeforeCorrection = weight;
  }

  /** Poses de la trayectoria, de la más reciente a la inicial. */
  trajectoryPoints() {
    const points = [];
    for (let node = this.trajectory; node; node = node.previous) points.push(node);
    return points;
  }

  /** Copia barata: mapa, trayectoria y asociaciones son inmutables y se comparten. */
  clone() {
    const copy = new Particle({ ...this, pose: { ...this.pose } });
    copy.weightBeforeCorrection = this.weightBeforeCorrection;
    return copy;
  }
}

export class FastSlamFilter {
  /**
   * @param {object} options
   * @param {number} options.particleCount  N
   * @param {'known'|'maximumLikelihood'} options.association  correspondencias
   * @param {number} options.motionNoise    Q: factor de ruido del modelo de movimiento
   * @param {object} options.measurementNoise  R: { range, bearing } que supone el filtro
   */
  constructor({ particleCount, association, motionNoise, measurementNoise, startPose, rng }) {
    this.association = association;
    this.motionNoise = motionNoise;
    this.R = measurementCovariance(measurementNoise);
    // Factor de peso de una observación que crea un landmark nuevo: la verosimilitud
    // que tendría una coincidencia justo en el límite de la puerta.
    this.newLandmarkLikelihood =
      Math.exp(-0.5 * ASSOCIATION_GATE) / (2 * Math.PI * Math.sqrt(Mat2.determinant(this.R)));
    this.rng = rng;
    const start = { x: startPose.x, y: startPose.y, previous: null };
    this.particles = Array.from({ length: particleCount }, () => new Particle({
      pose: { ...startPose }, weight: 1 / particleCount, landmarks: [], trajectory: start,
    }));
  }

  get count() {
    return this.particles.length;
  }

  /** 1. Predicción: cada partícula muestrea su nueva pose del modelo de movimiento. */
  predict(u) {
    for (const particle of this.particles) {
      particle.pose = sampleMotionModel(particle.pose, u, this.motionNoise, this.rng);
      particle.trajectory = { x: particle.pose.x, y: particle.pose.y, previous: particle.trajectory };
    }
  }

  /**
   * 2. Corrección. Para cada partícula y cada observación:
   *    asociar con un landmark de SU mapa (o crear uno nuevo), corregir el EKF de ese
   *    landmark y multiplicar el peso por la verosimilitud de la observación.
   * Devuelve Neff tras normalizar los pesos.
   */
  correct(observations) {
    const logLikelihoods = this.particles.map((particle) => {
      // El vector puede estar compartido con hermanas tras el remuestreo: se crea uno
      // nuevo (solo se copian referencias; los landmarks que no cambian se comparten).
      const landmarks = particle.landmarks.slice();
      const associations = [];
      let logLikelihood = 0;

      for (const observation of observations) {
        const index = this.#associate(landmarks, particle.pose, observation);
        if (index < 0) {
          landmarks.push(Landmark.fromObservation(particle.pose, observation, this.R));
          associations.push({ observation, landmarkIndex: landmarks.length - 1, isNew: true });
          logLikelihood += Math.log(this.newLandmarkLikelihood);
        } else {
          const comparison = landmarks[index].compare(particle.pose, observation, this.R);
          landmarks[index] = landmarks[index].corrected(comparison);
          associations.push({ observation, landmarkIndex: index, isNew: false });
          logLikelihood += Math.log(comparison.likelihood);
        }
      }

      particle.landmarks = landmarks;
      particle.associations = associations;
      particle.weightBeforeCorrection = particle.weight;
      return logLikelihood;
    });

    this.#multiplyWeights(logLikelihoods);
    return this.effectiveSampleSize();
  }

  /**
   * 3. Remuestreo, solo si Neff < N/2. Devuelve cuántos mapas se habrían copiado en
   * una implementación ingenua y cuántos landmarks suman.
   */
  resampleIfNeeded() {
    if (this.effectiveSampleSize() >= this.count / 2) {
      return { resampled: false, mapsCopied: 0, landmarksCopied: 0 };
    }
    return { resampled: true, ...this.#resample() };
  }

  /** Neff = 1 / Σ w_i² (con pesos normalizados). */
  effectiveSampleSize() {
    let sumOfSquares = 0;
    for (const p of this.particles) sumOfSquares += p.weight * p.weight;
    return 1 / sumOfSquares;
  }

  bestIndex() {
    let best = 0;
    this.particles.forEach((p, i) => {
      if (p.weight > this.particles[best].weight) best = i;
    });
    return best;
  }

  /** Estado completo del filtro (partículas y generador aleatorio), para volver atrás. */
  snapshot() {
    return { particles: this.particles.map((p) => p.clone()), rngState: this.rng.state };
  }

  restore(snapshot) {
    this.particles = snapshot.particles.map((p) => p.clone());
    this.rng.state = snapshot.rngState;
  }

  /** Índice del landmark que corresponde a la observación, o -1 si es nuevo. */
  #associate(landmarks, pose, observation) {
    if (this.association === 'known') {
      return landmarks.findIndex((l) => l.sourceId === observation.id);
    }
    // Máxima verosimilitud, entre las candidatas que pasan la puerta de Mahalanobis.
    // Solo se comparan los landmarks que podrían estar al alcance del sensor.
    const reach = SENSOR.maxRange + 1;
    let best = -1;
    let bestLikelihood = 0;
    landmarks.forEach((landmark, j) => {
      if (Math.hypot(landmark.mean[0] - pose.x, landmark.mean[1] - pose.y) > reach) return;
      const { mahalanobis2, likelihood } = landmark.compare(pose, observation, this.R);
      if (mahalanobis2 < ASSOCIATION_GATE && likelihood > bestLikelihood) {
        best = j;
        bestLikelihood = likelihood;
      }
    });
    return best;
  }

  /** w_i ← w_i · exp(log-verosimilitud), restando el máximo para evitar desbordes, y normalizar. */
  #multiplyWeights(logLikelihoods) {
    const max = Math.max(...logLikelihoods);
    let sum = 0;
    this.particles.forEach((p, i) => {
      p.weight *= Math.exp(logLikelihoods[i] - max);
      sum += p.weight;
    });
    for (const p of this.particles) p.weight /= sum;
  }

  /**
   * Remuestreo de baja varianza: se eligen N madres con un único número aleatorio.
   * Las hijas comparten la trayectoria y el vector de landmarks de su madre.
   */
  #resample() {
    const old = this.particles;
    const N = old.length;
    const parents = [];
    const r = this.rng.uniform() / N;
    let cumulative = old[0].weight;
    let i = 0;
    for (let m = 0; m < N; m++) {
      const target = r + m / N;
      while (target > cumulative && i < N - 1) {
        i++;
        cumulative += old[i].weight;
      }
      parents.push(i);
    }

    // En una implementación ingenua, cada hija salvo una copia el mapa entero: O(N·M)
    const seen = new Set();
    let mapsCopied = 0;
    let landmarksCopied = 0;
    for (const k of parents) {
      if (seen.has(k)) {
        mapsCopied++;
        landmarksCopied += old[k].landmarks.length;
      }
      seen.add(k);
    }

    this.particles = parents.map((k) => new Particle({
      pose: { ...old[k].pose },
      weight: 1 / N,
      landmarks: old[k].landmarks,
      trajectory: old[k].trajectory,
      parentIndex: k,
      associations: old[k].associations,
    }));
    return { mapsCopied, landmarksCopied };
  }
}
