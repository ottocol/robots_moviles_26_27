// Ángulos y matrices 2x2. Una matriz 2x2 se guarda como [a, b, c, d] = [[a, b], [c, d]].

export const DEG = Math.PI / 180;

/** Normaliza un ángulo a (-π, π]. */
export function wrapAngle(angle) {
  return Math.atan2(Math.sin(angle), Math.cos(angle));
}

export const Mat2 = {
  identity: [1, 0, 0, 1],
  multiply: (A, B) => [
    A[0] * B[0] + A[1] * B[2], A[0] * B[1] + A[1] * B[3],
    A[2] * B[0] + A[3] * B[2], A[2] * B[1] + A[3] * B[3],
  ],
  transpose: (A) => [A[0], A[2], A[1], A[3]],
  add: (A, B) => [A[0] + B[0], A[1] + B[1], A[2] + B[2], A[3] + B[3]],
  subtract: (A, B) => [A[0] - B[0], A[1] - B[1], A[2] - B[2], A[3] - B[3]],
  determinant: (A) => A[0] * A[3] - A[1] * A[2],
  inverse: (A) => {
    const d = A[0] * A[3] - A[1] * A[2];
    return [A[3] / d, -A[1] / d, -A[2] / d, A[0] / d];
  },
  /** Matriz por vector columna [x, y]. */
  apply: (A, v) => [A[0] * v[0] + A[1] * v[1], A[2] * v[0] + A[3] * v[1]],
};
