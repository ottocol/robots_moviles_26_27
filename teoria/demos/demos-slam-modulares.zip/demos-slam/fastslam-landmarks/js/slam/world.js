import { Random } from './random.js';

// El mundo simulado: una zona de 16 x 12 m con landmarks puntuales a lo largo de un
// ciclo rectangular. Coordenadas en metros, eje y hacia arriba, ángulos en radianes.

export const WORLD = { width: 16, height: 12 };

// Zona que se dibuja: el mundo más 1 m de margen por cada lado.
export const MAP_BOUNDS = { x0: -1, y0: -1, width: 18, height: 14 };

export const START_POSE = Object.freeze({ x: 2, y: 2, theta: 0 });

// Esquinas del ciclo (sentido antihorario). La ruta da la vuelta completa y repite
// unos metros del principio para que se vea bien el cierre.
export const LOOP_CORNERS = [[2, 2], [14, 2], [14, 10], [2, 10]];
export const LOOP_ROUTE = [[14, 2], [14, 10], [2, 10], [2, 2], [8, 2]];

/**
 * Landmarks reales { id, x, y }: uno cada 1,7 m a lo largo del ciclo, alternando
 * dentro y fuera, a entre 1 y 2,2 m del camino. Siempre son los mismos (semilla fija).
 */
export const LANDMARKS = (() => {
  const rng = new Random(2024);
  const spacing = 1.7;
  const landmarks = [];
  let side = 1;
  LOOP_CORNERS.forEach(([ax, ay], s) => {
    const [bx, by] = LOOP_CORNERS[(s + 1) % LOOP_CORNERS.length];
    const length = Math.hypot(bx - ax, by - ay);
    const ux = (bx - ax) / length;   // dirección del tramo
    const uy = (by - ay) / length;
    const nx = -uy;                  // normal hacia el interior del ciclo
    const ny = ux;
    for (let d = spacing / 2; d < length; d += spacing) {
      const along = d + (rng.uniform() - 0.5) * 0.6;
      const offset = side * (1 + rng.uniform() * 1.2);
      side = -side;
      landmarks.push({
        id: landmarks.length,
        x: ax + ux * along + nx * offset,
        y: ay + uy * along + ny * offset,
      });
    }
  });
  return landmarks;
})();
