import { wrapAngle, Mat2 } from './geometry.js';

// Un landmark del mapa de una partícula: un EKF de 2x2 (media y covarianza).
// Los landmarks son INMUTABLES: la corrección devuelve un landmark nuevo. Así, tras el
// remuestreo, las copias de una partícula pueden compartir landmarks sin copiarlos.

/** R: covarianza del sensor que supone el filtro, a partir de sus desviaciones típicas. */
export function measurementCovariance({ range, bearing }) {
  return [range * range, 0, 0, bearing * bearing];
}

/**
 * Observación esperada ẑ = h(x, m) = [distancia, ángulo] de un landmark en `mean`
 * visto desde `pose`, y su jacobiano H respecto a la posición del landmark.
 */
export function expectedObservation(pose, mean) {
  const dx = mean[0] - pose.x;
  const dy = mean[1] - pose.y;
  const q = dx * dx + dy * dy;
  const r = Math.sqrt(q);
  return {
    expected: [r, wrapAngle(Math.atan2(dy, dx) - pose.theta)],
    H: [dx / r, dy / r, -dy / q, dx / q],
  };
}

export class Landmark {
  /**
   * @param {number[]} mean        posición estimada [x, y]
   * @param {number[]} covariance  covarianza 2x2 [a, b, c, d]
   * @param {number} sourceId      landmark real que lo originó. SOLO para diagnóstico
   *                               (errores, duplicados) o con correspondencias conocidas.
   * @param {number} timesObserved
   */
  constructor(mean, covariance, sourceId, timesObserved) {
    this.mean = mean;
    this.covariance = covariance;
    this.sourceId = sourceId;
    this.timesObserved = timesObserved;
    Object.freeze(this);
  }

  /** Landmark nuevo a partir de una observación: m = pose + z, P = H⁻¹ R H⁻ᵀ. */
  static fromObservation(pose, observation, R) {
    const angle = pose.theta + observation.bearing;
    const mean = [pose.x + observation.range * Math.cos(angle), pose.y + observation.range * Math.sin(angle)];
    const Hinv = Mat2.inverse(expectedObservation(pose, mean).H);
    const covariance = Mat2.multiply(Mat2.multiply(Hinv, R), Mat2.transpose(Hinv));
    return new Landmark(mean, covariance, observation.id, 1);
  }

  /**
   * Compara una observación con lo que se esperaría ver de este landmark desde `pose`.
   * Devuelve la innovación ν = z − ẑ, su covarianza S = H P Hᵀ + R, la distancia de
   * Mahalanobis² νᵀ S⁻¹ ν y la verosimilitud N(ν; 0, S), que es el peso de la observación.
   */
  compare(pose, observation, R) {
    const { expected, H } = expectedObservation(pose, this.mean);
    const innovation = [observation.range - expected[0], wrapAngle(observation.bearing - expected[1])];
    const S = Mat2.add(Mat2.multiply(Mat2.multiply(H, this.covariance), Mat2.transpose(H)), R);
    const Sinv = Mat2.inverse(S);
    const weighted = Mat2.apply(Sinv, innovation);
    const mahalanobis2 = innovation[0] * weighted[0] + innovation[1] * weighted[1];
    const likelihood = Math.exp(-0.5 * mahalanobis2) / (2 * Math.PI * Math.sqrt(Mat2.determinant(S)));
    return { innovation, H, Sinv, mahalanobis2, likelihood };
  }

  /** Corrección del EKF con el resultado de compare(): K = P Hᵀ S⁻¹, m += K ν, P = (I − K H) P. */
  corrected({ innovation, H, Sinv }) {
    const P = this.covariance;
    const K = Mat2.multiply(Mat2.multiply(P, Mat2.transpose(H)), Sinv);
    const shift = Mat2.apply(K, innovation);
    const mean = [this.mean[0] + shift[0], this.mean[1] + shift[1]];
    const updated = Mat2.multiply(Mat2.subtract(Mat2.identity, Mat2.multiply(K, H)), P);
    const offDiagonal = (updated[1] + updated[2]) / 2;  // mantenerla simétrica
    const covariance = [updated[0], offDiagonal, offDiagonal, updated[3]];
    return new Landmark(mean, covariance, this.sourceId, this.timesObserved + 1);
  }
}
