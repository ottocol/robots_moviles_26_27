import { DEG, wrapAngle } from './geometry.js';
import { LANDMARKS } from './world.js';

// Movimiento y sensor. Una orden u = { rotation, translation } significa: primero
// girar `rotation` radianes y luego avanzar `translation` metros.

// La rueda real gira un 5 % más de lo que dice la odometría: un error sistemático
// que hace que la estimación solo con odometría se desvíe al dar la vuelta.
export const ODOMETRY_BIAS = 0.05;

// Sensor de distancia y orientación (rango-bearing), 360°.
export const SENSOR = { maxRange: 4 };

// Ruido real del sensor simulado (desviaciones típicas), si no se cambia en la página.
export const DEFAULT_SENSOR_NOISE = { range: 0.08, bearing: 1.5 * DEG };

/** Movimiento real del robot: la orden con sesgo y ruido. */
export function moveRealRobot(pose, u, rng) {
  const rotation = u.rotation * (1 + ODOMETRY_BIAS) +
    rng.gaussian() * (0.03 * Math.abs(u.rotation) + 0.01 * Math.abs(u.translation));
  const translation = u.translation * (1 + rng.gaussian() * 0.03);
  const theta = wrapAngle(pose.theta + rotation);
  return { x: pose.x + translation * Math.cos(theta), y: pose.y + translation * Math.sin(theta), theta };
}

/** Integración de la odometría sin ruido (la estimación «solo odometría»). */
export function integrateOdometry(pose, u) {
  const theta = wrapAngle(pose.theta + u.rotation);
  return { x: pose.x + u.translation * Math.cos(theta), y: pose.y + u.translation * Math.sin(theta), theta };
}

/**
 * Modelo de movimiento del filtro: muestrea x_t ~ p(x_t | u_t, x_{t-1}).
 * `noiseScale` multiplica todas las desviaciones típicas.
 */
export function sampleMotionModel(pose, u, noiseScale, rng) {
  const rotation = u.rotation + rng.gaussian() * noiseScale *
    (0.08 * Math.abs(u.rotation) + 0.04 * Math.abs(u.translation) + 0.004);
  const translation = u.translation + rng.gaussian() * noiseScale *
    (0.06 * Math.abs(u.translation) + 0.005);
  const theta = wrapAngle(pose.theta + rotation);
  return { x: pose.x + translation * Math.cos(theta), y: pose.y + translation * Math.sin(theta), theta };
}

/**
 * Observaciones z_t desde la pose real: { id, range, bearing } para cada landmark
 * a menos de SENSOR.maxRange, con ruido gaussiano de desviaciones `noise`.
 * El `id` es la verdad del simulador: el filtro solo lo usa si las correspondencias
 * son conocidas.
 */
export function observeLandmarks(pose, noise, rng) {
  const observations = [];
  for (const landmark of LANDMARKS) {
    const dx = landmark.x - pose.x;
    const dy = landmark.y - pose.y;
    const distance = Math.hypot(dx, dy);
    if (distance > SENSOR.maxRange) continue;
    observations.push({
      id: landmark.id,
      range: distance + rng.gaussian() * noise.range,
      bearing: wrapAngle(Math.atan2(dy, dx) - pose.theta + rng.gaussian() * noise.bearing),
    });
  }
  return observations;
}
