import { Random } from './random.js';
import { START_POSE } from './world.js';
import { FastSlamFilter } from './fastslam.js';

// Recorre el dataset con el filtro, fase a fase. Cada paso k tiene tres fases
// (predicción, corrección, remuestreo), así que la posición en la línea de tiempo es
// un entero: 0 = inicio; 3k−2, 3k−1 y 3k = el paso k tras cada fase.
//
// Para retroceder se vuelve al último punto de control anterior y se rehace desde
// ahí. Guardar un punto de control es barato porque landmarks y trayectorias son
// inmutables: basta con copiar referencias.

export const PHASES = ['prediction', 'correction', 'resampling'];
export const CHECKPOINT_EVERY = 30;  // posiciones (10 pasos)

export class Simulation {
  /**
   * @param {object} dataset  resultado de generateDataset()
   * @param {object} config   { seed, particleCount, association, motionNoise, measurementNoise }
   */
  constructor(dataset, config) {
    this.dataset = dataset;
    this.config = { ...config };
    this.filter = new FastSlamFilter({
      particleCount: config.particleCount,
      association: config.association,
      motionNoise: config.motionNoise,
      measurementNoise: config.measurementNoise,
      startPose: START_POSE,
      // Generador propio del filtro: cambiar ajustes no altera el mundo
      rng: new Random(config.seed * 7919 + 17),
    });
    this.position = 0;

    // Estadísticas para la interfaz
    this.neffHistory = [];       // Neff / N tras cada corrección, por paso
    this.resampleSteps = [];     // pasos en los que se remuestreó
    this.landmarksCopied = 0;    // acumulado, implementación ingenua
    this.lastResample = null;    // resultado del último remuestreo

    // Paso 0: la pose inicial es conocida; la primera observación crea los landmarks
    const neff = this.filter.correct(dataset.steps[0].observations);
    this.neffHistory.push(neff / this.filter.count);

    this.checkpoints = new Map();
    this.#saveCheckpoint();
  }

  get particles() {
    return this.filter.particles;
  }

  get lastPosition() {
    return 3 * this.dataset.lastStep;
  }

  /** Paso al que pertenece la posición actual. */
  get step() {
    return Math.ceil(this.position / 3);
  }

  /** 'start' | 'prediction' | 'correction' | 'resampling': última fase aplicada. */
  get phase() {
    return this.position === 0 ? 'start' : PHASES[(this.position - 1) % 3];
  }

  /** Posición en la que hay que parar antes de cerrar el ciclo: tras la predicción del paso de cierre. */
  get closurePosition() {
    return this.dataset.closureStep > 0 ? 3 * this.dataset.closureStep - 2 : -1;
  }

  /** Datos del dataset para el paso actual (pose real, orden, observaciones). */
  get stepData() {
    return this.dataset.steps[this.step];
  }

  /** Aplica la siguiente fase. Devuelve false si ya se ha terminado el recorrido. */
  advancePhase() {
    if (this.position >= this.lastPosition) return false;
    this.position++;
    const { u, observations } = this.stepData;

    if (this.phase === 'prediction') {
      this.filter.predict(u);
    } else if (this.phase === 'correction') {
      const neff = this.filter.correct(observations);
      this.neffHistory.push(neff / this.filter.count);
    } else {
      this.lastResample = this.filter.resampleIfNeeded();
      if (this.lastResample.resampled) {
        this.resampleSteps.push(this.step);
        this.landmarksCopied += this.lastResample.landmarksCopied;
      }
    }

    if (this.position % CHECKPOINT_EVERY === 0 && !this.checkpoints.has(this.position)) {
      this.#saveCheckpoint();
    }
    return true;
  }

  /** Lleva la simulación a `position`, hacia delante o hacia atrás. */
  goTo(position) {
    const target = Math.max(0, Math.min(this.lastPosition, position));
    if (target < this.position) {
      const from = Math.floor(target / CHECKPOINT_EVERY) * CHECKPOINT_EVERY;
      this.#restoreCheckpoint(this.checkpoints.get(from));
    }
    while (this.position < target) this.advancePhase();
  }

  #saveCheckpoint() {
    this.checkpoints.set(this.position, {
      position: this.position,
      filter: this.filter.snapshot(),
      neffCount: this.neffHistory.length,
      resampleCount: this.resampleSteps.length,
      landmarksCopied: this.landmarksCopied,
      lastResample: this.lastResample,
    });
  }

  #restoreCheckpoint(checkpoint) {
    this.position = checkpoint.position;
    this.filter.restore(checkpoint.filter);
    this.neffHistory.length = checkpoint.neffCount;
    this.resampleSteps.length = checkpoint.resampleCount;
    this.landmarksCopied = checkpoint.landmarksCopied;
    this.lastResample = checkpoint.lastResample;
  }
}
