import { Random } from './random.js';
import { START_POSE, LOOP_ROUTE } from './world.js';
import { DEFAULT_SENSOR_NOISE, moveRealRobot, integrateOdometry, observeLandmarks } from './robot.js';
import { RouteFollower } from './route.js';

// El recorrido completo se genera de una vez, como si fuera un rosbag: para cada paso,
// lo que registra el robot (orden u y observaciones z) y la verdad del simulador
// (pose real). El filtro solo lee u y z. Como el mundo no depende del filtro,
// se puede volver atrás o cambiar ajustes del filtro y el robot repite el mismo recorrido.

// Un landmark cuenta como «antiguo» si no se veía desde hace más de estos pasos.
export const REVISIT_GAP_STEPS = 40;

/**
 * Devuelve { steps, lastStep, closureStep }.
 * steps[k] = { u, truePose, odometryPose, observations, revisitedIds }
 * El paso 0 es la observación inicial desde la pose de salida (u = null).
 * closureStep es el primer paso que vuelve a ver un landmark antiguo: el cierre de ciclo.
 * Cambiar `sensorNoise` no cambia el recorrido: solo escala el ruido de las medidas.
 */
export function generateDataset(seed, sensorNoise = DEFAULT_SENSOR_NOISE) {
  const rng = new Random(seed);
  const route = new RouteFollower(LOOP_ROUTE);
  const lastSeen = new Map();  // id del landmark -> último paso en que se vio
  const steps = [];
  let truePose = { ...START_POSE };
  let odometryPose = { ...START_POSE };

  const record = (u) => {
    const k = steps.length;
    const observations = observeLandmarks(truePose, sensorNoise, rng);
    const revisitedIds = observations
      .filter((o) => lastSeen.has(o.id) && k - lastSeen.get(o.id) > REVISIT_GAP_STEPS)
      .map((o) => o.id);
    for (const o of observations) lastSeen.set(o.id, k);
    steps.push({ u, truePose, odometryPose, observations, revisitedIds });
  };

  record(null);
  for (let u = route.nextCommand(truePose); u && steps.length < 2000; u = route.nextCommand(truePose)) {
    truePose = moveRealRobot(truePose, u, rng);
    odometryPose = integrateOdometry(odometryPose, u);
    record(u);
  }

  return {
    steps,
    lastStep: steps.length - 1,
    closureStep: steps.findIndex((s) => s.revisitedIds.length > 0),
  };
}
