// Genera la versión de un solo archivo (dist/<carpeta>.html) a partir de index.html,
// la hoja de estilos y los módulos JS. Uso, desde la carpeta de la demo:
//
//     node build.mjs
//
// Qué hace:
//   1. Sustituye cada <link rel="stylesheet" href="css/..."> por su contenido.
//   2. Para <script type="module" src="...">, recorre los import desde ese archivo,
//      ordena los módulos de forma que cada uno vaya después de los que importa, quita
//      las líneas import y las palabras export, y lo mete todo en un único <script>.
//   3. Un <script src="..."> normal se copia tal cual dentro de la página.
// El resultado no necesita servidor: se abre con doble clic.

import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, relative, basename, resolve } from 'node:path';

const root = resolve('.');
let html = readFileSync(join(root, 'index.html'), 'utf8');

// 1. Estilos
html = html.replace(/<link rel="stylesheet" href="(css\/[^"]+)">/g,
  (_, href) => `<style>\n${readFileSync(join(root, href), 'utf8')}</style>`);

// 2 y 3. Scripts
html = html.replace(/<script( type="module")? src="([^"]+)"><\/script>/g, (_, isModule, src) => {
  if (!isModule) return `<script>\n${readFileSync(join(root, src), 'utf8')}</script>`;
  return `<script type="module">\n${bundle(join(root, src))}</script>`;
});

const out = join(root, 'dist', `${basename(root)}.html`);
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, html);
console.log(`Generado ${relative(root, out)}`);

/** Concatena un módulo y todas sus dependencias, primero las dependencias. */
function bundle(entry) {
  const ordered = [];
  const visiting = new Set();
  const done = new Set();

  const visit = (file) => {
    if (done.has(file)) return;
    if (visiting.has(file)) throw new Error(`Importación circular en ${relative(root, file)}`);
    visiting.add(file);
    const code = readFileSync(file, 'utf8');
    for (const [, path] of code.matchAll(/^import .* from '([^']+)';$/gm)) {
      visit(resolve(dirname(file), path));
    }
    visiting.delete(file);
    done.add(file);
    ordered.push(file);
  };
  visit(entry);

  return ordered.map((file) => {
    const code = readFileSync(file, 'utf8')
      .replace(/^import .* from '[^']+';\n/gm, '')
      .replace(/^export /gm, '')
      .replace(/^\n+/, '');
    return `// ===== ${relative(root, file)} =====\n${code}`;
  }).join('\n');
}
