# Demos de SLAM · Robots Móviles

| Carpeta | Qué es |
|---|---|
| `fastslam-rejillas/` | FastSLAM con rejillas de ocupación: propuesta mejorada (tipo GMapping), láser y entorno configurables |
| `fastslam-landmarks/` | FastSLAM 1.0 con landmarks: EKF por landmark, avance fase a fase, ruido del sensor y R |
| `grafo-1d/` | Ejemplo 1D de SLAM con grafos con pesos (muelles) |
| `grafo-poses-2d/` | Grafo de poses 2D optimizado con Gauss-Newton y la matriz H por bloques |

Cada carpeta tiene la misma estructura:

```
index.html          versión con módulos (css/ y js/ separados)
css/estilos.css
js/...              un archivo por responsabilidad (mundo, sensor, filtro, dibujo, interfaz…)
build.mjs           regenera dist/ a partir de index.html, css/ y js/
dist/<demo>.html    versión de un solo archivo
```

## Abrir las demos

- **Un solo archivo** (`dist/<demo>.html`): doble clic. No necesita servidor ni conexión
  (sin conexión solo cambia la tipografía).
- **Versión con módulos** (`index.html`): los navegadores no cargan módulos ES desde
  `file://`, así que hace falta un servidor local. Desde la carpeta de la demo:

  ```
  python3 -m http.server 8000
  ```

  y abrir http://localhost:8000. También vale la extensión Live Server de VS Code
  o `npx serve`. La demo `grafo-1d` no usa módulos y funciona también con doble clic.

## Si modificas los .js

Desde la carpeta de la demo:

```
node build.mjs
```

Vuelve a generar `dist/<demo>.html` con los cambios (necesita Node 18 o posterior).
Recorre los `import` desde `js/ui/main.js`, ordena los módulos y los mete en un único
`<script>`, sin `import` ni `export`.
