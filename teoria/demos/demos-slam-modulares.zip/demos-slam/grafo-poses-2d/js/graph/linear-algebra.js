// Matrices pequeñas como arrays de filas. Solo lo imprescindible.

/** Matriz rows x cols llena de ceros. */
export function zeros(rows, cols) {
  return Array.from({ length: rows }, () => new Array(cols).fill(0));
}

/** Aᵀ · W · B para bloques de 3x3 (W diagonal, dada como [w0, w1, w2]). */
export function transposeWeightedProduct(A, w, B) {
  const result = zeros(3, 3);
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      let sum = 0;
      for (let k = 0; k < 3; k++) sum += A[k][r] * w[k] * B[k][c];
      result[r][c] = sum;
    }
  }
  return result;
}

/** Aᵀ · W · e para un bloque 3x3 y un vector de 3. */
export function transposeWeightedVector(A, w, e) {
  return [0, 1, 2].map((r) => A[0][r] * w[0] * e[0] + A[1][r] * w[1] * e[1] + A[2][r] * w[2] * e[2]);
}

/** Resuelve A·x = b por eliminación gaussiana con pivoteo parcial (A es pequeña). */
export function solveLinearSystem(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let r = col + 1; r < n; r++) if (Math.abs(M[r][col]) > Math.abs(M[pivot][col])) pivot = r;
    [M[col], M[pivot]] = [M[pivot], M[col]];
    for (let r = col + 1; r < n; r++) {
      const factor = M[r][col] / M[col][col];
      if (factor === 0) continue;
      for (let c = col; c <= n; c++) M[r][c] -= factor * M[col][c];
    }
  }
  const x = new Array(n).fill(0);
  for (let r = n - 1; r >= 0; r--) {
    let sum = M[r][n];
    for (let c = r + 1; c < n; c++) sum -= M[r][c] * x[c];
    x[r] = sum / M[r][r];
  }
  return x;
}
