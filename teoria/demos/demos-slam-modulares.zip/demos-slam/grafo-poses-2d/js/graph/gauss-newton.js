import { wrapAngle, relativePose } from './pose.js';
import { zeros, transposeWeightedProduct, transposeWeightedVector, solveLinearSystem } from './linear-algebra.js';

// Optimización del grafo de poses por Gauss-Newton.
//
// Cada arista es un muelle. Su error compara la medida con lo que dice la estimación:
//     e = (pose j vista desde la pose i) − medida
// y la energía total es F = Σ eᵀ Ω e, con Ω la matriz de pesos (inversa de la
// covarianza de la medida). Como «vista desde i» lleva senos y cosenos de θᵢ, F no es
// una parábola perfecta: en cada iteración se linealiza en la estimación actual, se
// resuelve como en 1D y se repite.

/** Error de una arista con la estimación actual: [ex, ey, eθ]. */
export function edgeError(poses, edge) {
  const seen = relativePose(poses[edge.from], poses[edge.to]);
  return [
    seen.x - edge.measurement.x,
    seen.y - edge.measurement.y,
    wrapAngle(seen.theta - edge.measurement.theta),
  ];
}

/**
 * Jacobianos del error respecto a la pose i (A) y a la pose j (B): cuánto cambia
 * cada componente del error al mover un poco x, y o θ de cada pose.
 */
export function edgeJacobians(poses, edge) {
  const pi = poses[edge.from];
  const pj = poses[edge.to];
  const c = Math.cos(pi.theta);
  const s = Math.sin(pi.theta);
  const dx = pj.x - pi.x;
  const dy = pj.y - pi.y;
  const A = [
    [-c, -s, -s * dx + c * dy],   // girar la pose i hace que j se vea en otro sitio
    [s, -c, -c * dx - s * dy],
    [0, 0, -1],
  ];
  const B = [
    [c, s, 0],
    [-s, c, 0],
    [0, 0, 1],
  ];
  return { A, B };
}

/** Energía total F = Σ eᵀ Ω e. */
export function totalError(poses, edges, weights) {
  let total = 0;
  for (const edge of edges) {
    const e = edgeError(poses, edge);
    const w = weights[edge.kind];
    total += w[0] * e[0] * e[0] + w[1] * e[1] * e[1] + w[2] * e[2] * e[2];
  }
  return total;
}

/**
 * Monta H y b linealizando en `poses`. Cada arista i→j suma cuatro bloques de 3x3 en H
 * (AᵀΩA en ii, AᵀΩB en ij, BᵀΩA en ji, BᵀΩB en jj) y dos en b. Es lo mismo que en 1D,
 * con bloques en vez de números.
 * También devuelve, para dibujarla, qué aristas aportan a cada bloque fuera de la diagonal.
 */
export function buildSystem(poses, edges, weights) {
  const n = poses.length;
  const H = zeros(3 * n, 3 * n);
  const b = new Array(3 * n).fill(0);
  const blockSources = new Map();  // "i,j" -> tipo de arista

  const addBlock = (row, col, block) => {
    for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) H[3 * row + r][3 * col + c] += block[r][c];
  };
  const addVector = (row, vector) => {
    for (let r = 0; r < 3; r++) b[3 * row + r] += vector[r];
  };

  for (const edge of edges) {
    const e = edgeError(poses, edge);
    const { A, B } = edgeJacobians(poses, edge);
    const w = weights[edge.kind];
    const { from: i, to: j } = edge;
    addBlock(i, i, transposeWeightedProduct(A, w, A));
    addBlock(i, j, transposeWeightedProduct(A, w, B));
    addBlock(j, i, transposeWeightedProduct(B, w, A));
    addBlock(j, j, transposeWeightedProduct(B, w, B));
    addVector(i, transposeWeightedVector(A, w, e));
    addVector(j, transposeWeightedVector(B, w, e));
    blockSources.set(`${i},${j}`, edge.kind);
    blockSources.set(`${j},${i}`, edge.kind);
  }
  return { H, b, blockSources };
}

/**
 * Una iteración de Gauss-Newton: montar H·Δx = −b, anclar la pose 0 (se quitan sus
 * filas y columnas, como al fijar x₁ en el ejemplo 1D), resolver y mover las poses.
 */
export function gaussNewtonStep(poses, edges, weights) {
  const { H, b } = buildSystem(poses, edges, weights);
  const free = H.slice(3).map((row) => row.slice(3));
  const delta = solveLinearSystem(free, b.slice(3).map((v) => -v));

  const next = poses.map((pose, k) => {
    if (k === 0) return pose;
    const d = delta.slice(3 * (k - 1), 3 * k);
    return { x: pose.x + d[0], y: pose.y + d[1], theta: wrapAngle(pose.theta + d[2]) };
  });

  // Cuánto se ha girado y desplazado de media en esta iteración
  let rotation = 0;
  let translation = 0;
  for (let k = 1; k < poses.length; k++) {
    rotation += Math.abs(wrapAngle(next[k].theta - poses[k].theta));
    translation += Math.hypot(next[k].x - poses[k].x, next[k].y - poses[k].y);
  }
  return {
    poses: next,
    meanRotation: rotation / (poses.length - 1),
    meanTranslation: translation / (poses.length - 1),
  };
}

/** Matriz de pesos Ω (diagonal) a partir de desviaciones típicas. */
export function informationFromSigmas(distance, angle, scale = 1) {
  return [scale / distance ** 2, scale / distance ** 2, scale / angle ** 2];
}
