// Poses 2D { x, y, theta } y las dos operaciones que hacen falta:
// componer (aplicar un movimiento relativo) y ver una pose desde otra.

export const DEG = Math.PI / 180;

/** Normaliza un ángulo a (-π, π]: 359° y 1° están a 2°, no a 358°. */
export function wrapAngle(angle) {
  return Math.atan2(Math.sin(angle), Math.cos(angle));
}

/** a ⊕ d: desde la pose a, avanzar d.x hacia delante, d.y a la izquierda y girar d.theta. */
export function compose(a, d) {
  const c = Math.cos(a.theta);
  const s = Math.sin(a.theta);
  return {
    x: a.x + c * d.x - s * d.y,
    y: a.y + s * d.x + c * d.y,
    theta: wrapAngle(a.theta + d.theta),
  };
}

/** Dónde está la pose b vista desde la pose a (en el sistema de referencia de a). */
export function relativePose(a, b) {
  const c = Math.cos(a.theta);
  const s = Math.sin(a.theta);
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  return { x: c * dx + s * dy, y: -s * dx + c * dy, theta: wrapAngle(b.theta - a.theta) };
}
