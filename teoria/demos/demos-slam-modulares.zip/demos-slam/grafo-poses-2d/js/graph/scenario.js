import { Random } from './random.js';
import { DEG, compose, relativePose } from './pose.js';

// El escenario: el robot recorre un cuadrado de 4 x 4 m en 16 poses (una cada metro,
// girando 90° en las esquinas). La odometría tiene una deriva de giro en cada paso; al
// final, el robot reconoce el punto de partida y mide dónde está la pose 0 vista desde
// la 15: el cierre de ciclo.

export const POSE_COUNT = 16;
export const ODOMETRY_NOISE = { distance: 0.02, angle: 0.5 * DEG };   // ruido real de la odometría
export const LOOP_NOISE = { distance: 0.01, angle: 0.3 * DEG };       // ruido real del cierre

/** Movimiento real entre la pose k y la k+1: avanzar 1 m y girar 90° si k+1 es esquina. */
export function trueMotion(k) {
  return { x: 1, y: 0, theta: (k + 1) % 4 === 0 ? 90 * DEG : 0 };
}

/**
 * Devuelve { truth, odometryEstimate, edges }.
 * Cada arista es { from, to, measurement, kind: 'odometry' | 'loop' }: la medida es la
 * pose de `to` vista desde `from`.
 * @param {number} driftPerStep  deriva de giro de la odometría en cada paso (rad)
 */
export function makeScenario(seed, driftPerStep) {
  const rng = new Random(seed);
  const truth = [{ x: 0, y: 0, theta: 0 }];
  for (let k = 0; k < POSE_COUNT - 1; k++) truth.push(compose(truth[k], trueMotion(k)));

  const edges = [];
  for (let k = 0; k < POSE_COUNT - 1; k++) {
    const real = trueMotion(k);
    edges.push({
      from: k,
      to: k + 1,
      kind: 'odometry',
      measurement: {
        x: real.x + rng.gaussian() * ODOMETRY_NOISE.distance,
        y: real.y + rng.gaussian() * ODOMETRY_NOISE.distance,
        theta: real.theta + driftPerStep + rng.gaussian() * ODOMETRY_NOISE.angle,
      },
    });
  }

  // Cierre de ciclo: pose 0 vista desde la 15, medida con un sensor (más preciso)
  const real = relativePose(truth[POSE_COUNT - 1], truth[0]);
  edges.push({
    from: POSE_COUNT - 1,
    to: 0,
    kind: 'loop',
    measurement: {
      x: real.x + rng.gaussian() * LOOP_NOISE.distance,
      y: real.y + rng.gaussian() * LOOP_NOISE.distance,
      theta: real.theta + rng.gaussian() * LOOP_NOISE.angle,
    },
  });

  // Estimación inicial: encadenar la odometría desde la pose 0, que es conocida
  const odometryEstimate = [truth[0]];
  for (const edge of edges.filter((e) => e.kind === 'odometry')) {
    odometryEstimate.push(compose(odometryEstimate[edge.from], edge.measurement));
  }
  return { truth, odometryEstimate, edges };
}
