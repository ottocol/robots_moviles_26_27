import { compose } from '../graph/pose.js';

// Dibujo de la trayectoria y de la matriz H. Solo lee el estado; no lo modifica.

export function readTheme() {
  const style = getComputedStyle(document.documentElement);
  const get = (name) => style.getPropertyValue(name).trim();
  return {
    bg: get('--bg'), surface: get('--surface'), ink: get('--ink'), muted: get('--muted'),
    line: get('--line'), odo: get('--odo'), loop: get('--loop'), truth: get('--truth'),
    drift: get('--drift'),
  };
}

/** Proyección de metros a píxeles que encaja unos límites en el lienzo, con el eje y hacia arriba. */
export class Projection {
  constructor(canvas, bounds) {
    const margin = 30;
    this.scale = Math.min((canvas.width - 2 * margin) / (bounds.maxX - bounds.minX),
                          (canvas.height - 2 * margin) / (bounds.maxY - bounds.minY));
    this.offsetX = (canvas.width - this.scale * (bounds.maxX - bounds.minX)) / 2 - this.scale * bounds.minX;
    this.offsetY = (canvas.height + this.scale * (bounds.maxY - bounds.minY)) / 2 + this.scale * bounds.minY;
  }
  x(x) { return this.offsetX + this.scale * x; }
  y(y) { return this.offsetY - this.scale * y; }
}

/** Límites que contienen todas las poses de varias trayectorias. */
export function boundsOf(trajectories) {
  const all = trajectories.flat();
  return {
    minX: Math.min(...all.map((p) => p.x)) - 0.6, maxX: Math.max(...all.map((p) => p.x)) + 0.6,
    minY: Math.min(...all.map((p) => p.y)) - 0.6, maxY: Math.max(...all.map((p) => p.y)) + 0.6,
  };
}

export function strokePolyline(ctx, view, poses) {
  ctx.beginPath();
  poses.forEach((p, k) => (k ? ctx.lineTo(view.x(p.x), view.y(p.y)) : ctx.moveTo(view.x(p.x), view.y(p.y))));
  ctx.stroke();
}

/** Pose como triángulo que apunta hacia su orientación. */
export function drawPoseMarker(ctx, view, pose, size, fill, stroke) {
  const x = view.x(pose.x);
  const y = view.y(pose.y);
  const a = -pose.theta;  // el eje y del lienzo va hacia abajo
  ctx.beginPath();
  ctx.moveTo(x + Math.cos(a) * size, y + Math.sin(a) * size);
  ctx.lineTo(x + Math.cos(a + 2.45) * size * 0.75, y + Math.sin(a + 2.45) * size * 0.75);
  ctx.lineTo(x + Math.cos(a - 2.45) * size * 0.75, y + Math.sin(a - 2.45) * size * 0.75);
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}

/**
 * Trayectorias: la real, la de la odometría, la estimación anterior y la actual con sus
 * aristas. Para el cierre se dibuja también dónde «quiere» el cierre que esté la pose 0
 * (vista desde la 15) y el muelle estirado hasta donde está.
 */
export function drawTrajectories(canvas, view, s, theme, { showTruth, showPrevious }) {
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = theme.surface;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.lineJoin = 'round';

  if (showTruth) {
    ctx.strokeStyle = theme.truth;
    ctx.lineWidth = 6;
    ctx.globalAlpha = 0.28;
    strokePolyline(ctx, view, [...s.scenario.truth, s.scenario.truth[0]]);
    ctx.globalAlpha = 1;
  }

  ctx.setLineDash([6, 5]);
  ctx.strokeStyle = theme.drift;
  ctx.lineWidth = 1.5;
  strokePolyline(ctx, view, s.scenario.odometryEstimate);
  ctx.setLineDash([]);

  if (showPrevious && s.previous) {
    ctx.strokeStyle = theme.muted;
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 1.5;
    strokePolyline(ctx, view, s.previous);
    for (const p of s.previous) drawPoseMarker(ctx, view, p, 7, null, theme.muted);
    ctx.globalAlpha = 1;
  }

  // Aristas de odometría de la estimación actual
  const poses = s.displayed;
  ctx.strokeStyle = theme.odo;
  ctx.lineWidth = 2.5;
  strokePolyline(ctx, view, poses);

  // Cierre de ciclo: dónde dice la medida que está la pose 0, y el muelle estirado
  if (s.loopEnabled) {
    const loop = s.scenario.edges.find((e) => e.kind === 'loop');
    const wanted = compose(poses[loop.from], loop.measurement);
    ctx.strokeStyle = theme.loop;
    ctx.lineWidth = 2.5;
    ctx.setLineDash([2, 4]);
    strokePolyline(ctx, view, [poses[loop.from], wanted]);
    ctx.setLineDash([]);
    ctx.lineWidth = 1.5;
    drawPoseMarker(ctx, view, wanted, 11, null, theme.loop);
    ctx.lineWidth = 3;
    strokePolyline(ctx, view, [wanted, poses[loop.to]]);
  }

  poses.forEach((p, k) => {
    ctx.lineWidth = 1;
    drawPoseMarker(ctx, view, p, 11, k === 0 ? theme.ink : theme.odo, theme.surface);
  });
  ctx.fillStyle = theme.ink;
  ctx.font = '600 12px "IBM Plex Mono", monospace';
  ctx.fillText('0 (anclada)', view.x(poses[0].x) + 12, view.y(poses[0].y) + 18);
  ctx.fillText('15', view.x(poses[15].x) + 12, view.y(poses[15].y) + 4);
}

/**
 * Matriz H por bloques de 3x3: diagonal en tinta, bloques de odometría en azul, del
 * cierre en magenta. La fila y la columna de la pose 0 salen tachadas: está anclada.
 */
export function drawHessian(canvas, system, n, theme) {
  const ctx = canvas.getContext('2d');
  const size = canvas.width;
  const label = 22;
  const cell = (size - label) / n;
  ctx.fillStyle = theme.surface;
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      let color = null;
      if (i === j) color = theme.ink;
      else if (system.blockSources.has(`${i},${j}`)) color = system.blockSources.get(`${i},${j}`) === 'loop' ? theme.loop : theme.odo;
      if (!color) continue;
      ctx.fillStyle = color;
      ctx.fillRect(label + j * cell + 1, label + i * cell + 1, cell - 2, cell - 2);
    }
  }

  // Rejilla de bloques
  ctx.strokeStyle = theme.line;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let k = 0; k <= n; k++) {
    ctx.moveTo(label + k * cell, label);
    ctx.lineTo(label + k * cell, size);
    ctx.moveTo(label, label + k * cell);
    ctx.lineTo(size, label + k * cell);
  }
  ctx.stroke();

  // Pose 0 anclada: fila y columna tachadas
  ctx.save();
  ctx.beginPath();
  ctx.rect(label, label, cell, size - label);
  ctx.rect(label + cell, label, size - label - cell, cell);
  ctx.clip();
  ctx.globalAlpha = 0.8;
  ctx.fillStyle = theme.surface;
  ctx.fillRect(0, 0, size, size);
  ctx.globalAlpha = 1;
  ctx.strokeStyle = theme.muted;
  ctx.beginPath();
  for (let t = -size; t < size; t += 6) {
    ctx.moveTo(t, 0);
    ctx.lineTo(t + size, size);
  }
  ctx.stroke();
  ctx.restore();

  ctx.fillStyle = theme.muted;
  ctx.font = '10px "IBM Plex Mono", monospace';
  ctx.textAlign = 'center';
  for (let k = 0; k < n; k += 3) {
    ctx.fillText(k, label + (k + 0.5) * cell, 14);
    ctx.fillText(k, 10, label + (k + 0.65) * cell);
  }
  ctx.fillText(n - 1, label + (n - 0.5) * cell, 14);
  ctx.fillText(n - 1, 10, label + (n - 0.35) * cell);
}
