import { DEG, wrapAngle, compose } from '../graph/pose.js';
import { makeScenario } from '../graph/scenario.js';
import { edgeError, totalError, buildSystem, gaussNewtonStep, informationFromSigmas } from '../graph/gauss-newton.js';
import { readTheme, Projection, boundsOf, drawTrajectories, drawHessian } from './render.js';

// Estado de la página, controles y animación de cada iteración.

const $ = (id) => document.getElementById(id);
const ANIMATION_MS = 650;
const MAX_ITERATIONS = 10;

const controls = {
  trajectory: $('trajectory'), hessian: $('hessian'),
  step: $('step'), converge: $('converge'), reset: $('reset'), newSeed: $('newSeed'),
  drift: $('drift'), driftValue: $('driftValue'),
  odoAngle: $('odoAngle'), odoAngleValue: $('odoAngleValue'),
  loopWeight: $('loopWeight'), loopWeightValue: $('loopWeightValue'),
  loopEnabled: $('loopEnabled'), showTruth: $('showTruth'), showPrevious: $('showPrevious'),
  iterations: $('iterations'), hessianInfo: $('hessianInfo'), loopInfo: $('loopInfo'),
  status: $('status'),
};

const state = {
  seed: 1,
  scenario: null,
  edges: [],          // aristas activas (con o sin cierre)
  weights: null,      // { odometry: Ω, loop: Ω } como diagonales
  poses: [],          // estimación actual
  previous: null,     // estimación antes de la última iteración
  displayed: [],      // lo que se dibuja (interpolado durante la animación)
  history: [],        // una fila por iteración
  animating: false,
  loopEnabled: true,
};

/** Lee los controles y vuelve a la estimación de la odometría. */
function reset() {
  state.scenario = makeScenario(state.seed, Number(controls.drift.value) * DEG);
  state.loopEnabled = controls.loopEnabled.checked;
  state.edges = state.scenario.edges.filter((e) => state.loopEnabled || e.kind === 'odometry');
  state.weights = {
    odometry: informationFromSigmas(0.05, Number(controls.odoAngle.value) * DEG),
    loop: informationFromSigmas(0.02, 0.5 * DEG, 10 ** Number(controls.loopWeight.value)),
  };
  state.poses = state.scenario.odometryEstimate;
  state.displayed = state.poses;
  state.previous = null;
  state.history = [{ iteration: 0, error: totalError(state.poses, state.edges, state.weights) }];

  updateLabels();
  render();
}

/** Una iteración de Gauss-Newton, animada. Devuelve una promesa que acaba con la animación. */
function iterate() {
  const result = gaussNewtonStep(state.poses, state.edges, state.weights);
  state.previous = state.poses;
  state.poses = result.poses;
  state.history.push({
    iteration: state.history.length,
    error: totalError(state.poses, state.edges, state.weights),
    rotation: result.meanRotation,
    translation: result.meanTranslation,
  });
  return animate(state.previous, state.poses);
}

/** Interpola de una estimación a otra (posición y ángulo) para que se vea el movimiento. */
function animate(from, to) {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  state.animating = true;
  updateButtons();
  return new Promise((resolve) => {
    const start = performance.now();
    const frame = (now) => {
      const t = reduced ? 1 : Math.min(1, (now - start) / ANIMATION_MS);
      const k = 1 - (1 - t) ** 3;
      state.displayed = from.map((a, i) => ({
        x: a.x + (to[i].x - a.x) * k,
        y: a.y + (to[i].y - a.y) * k,
        theta: a.theta + wrapAngle(to[i].theta - a.theta) * k,
      }));
      render();
      if (t < 1) {
        requestAnimationFrame(frame);
      } else {
        state.animating = false;
        render();
        resolve();
      }
    };
    requestAnimationFrame(frame);
  });
}

/** Itera hasta que las poses casi no se mueven (o MAX_ITERATIONS). */
async function converge() {
  for (let k = 0; k < MAX_ITERATIONS; k++) {
    await iterate();
    const last = state.history[state.history.length - 1];
    if (last.rotation < 0.01 * DEG && last.translation < 0.001) break;
  }
}

// ---------- Textos ----------

const fmt = (value, digits) => value.toLocaleString('es-ES', { minimumFractionDigits: digits, maximumFractionDigits: digits });

function formatEnergy(value) {
  if (value < 0.01) return value < 1e-9 ? '0' : value.toExponential(1).replace('.', ',');
  if (value < 1000) return fmt(value, value < 10 ? 2 : 1);
  return value.toExponential(2).replace('.', ',').replace('e+', ' · 10^');
}

/** Error medio de posición frente a la verdad. */
function meanPositionError(poses) {
  let total = 0;
  poses.forEach((p, k) => {
    total += Math.hypot(p.x - state.scenario.truth[k].x, p.y - state.scenario.truth[k].y);
  });
  return total / poses.length;
}

function updateLabels() {
  controls.driftValue.textContent = `${fmt(Number(controls.drift.value), 1)}°/paso`;
  controls.odoAngleValue.textContent = `${fmt(Number(controls.odoAngle.value), 1)}°`;
  const scale = 10 ** Number(controls.loopWeight.value);
  controls.loopWeightValue.textContent = `×${scale >= 1 ? fmt(scale, 0) : fmt(scale, scale >= 0.1 ? 1 : 2)}`;
  controls.loopWeight.disabled = !controls.loopEnabled.checked;
}

function updateIterationTable() {
  const rows = state.history.map((h, k) => {
    const previous = state.history[k - 1];
    const worse = previous && h.error > previous.error * 1.0001;
    return `<tr${worse ? ' class="worse"' : ''}>
      <td>${h.iteration === 0 ? 'odometría' : h.iteration}</td>
      <td>${formatEnergy(h.error)}${worse ? ' ↑' : ''}</td>
      <td>${h.rotation === undefined ? '–' : fmt(h.rotation / DEG, 1) + '°'}</td>
      <td>${h.translation === undefined ? '–' : fmt(h.translation * 100, 0) + ' cm'}</td>
    </tr>`;
  });
  controls.iterations.innerHTML = rows.join('');
}

function updateInfo(system) {
  const n = state.poses.length;
  const nonZero = n + 2 * state.edges.length;
  controls.hessianInfo.textContent =
    `${nonZero} de ${n * n} bloques de 3×3 no son cero (${fmt(100 * nonZero / (n * n), 0)} %). ` +
    'El patrón no cambia entre iteraciones: solo los valores.';

  const loop = state.edges.find((e) => e.kind === 'loop');
  if (loop) {
    const e = edgeError(state.poses, loop);
    controls.loopInfo.textContent =
      `Muelle del cierre estirado ${fmt(Math.hypot(e[0], e[1]) * 100, 1)} cm y torcido ${fmt(Math.abs(e[2]) / DEG, 1)}°. ` +
      `Error medio de posición frente a la realidad: ${fmt(meanPositionError(state.poses) * 100, 0)} cm.`;
  } else {
    controls.loopInfo.textContent =
      'Sin cierre de ciclo, la odometría ya cumple todas las restricciones: F = 0 y Gauss-Newton no mueve nada. ' +
      `Error medio frente a la realidad: ${fmt(meanPositionError(state.poses) * 100, 0)} cm.`;
  }
}

function updateButtons() {
  const last = state.history[state.history.length - 1];
  const converged = last.rotation !== undefined && last.rotation < 0.01 * DEG && last.translation < 0.001;
  controls.step.disabled = controls.converge.disabled = state.animating;
  controls.reset.disabled = state.animating || state.history.length === 1;
  controls.status.textContent = state.history.length === 1
    ? 'Estimación inicial: la odometría encadenada.'
    : `Iteración ${state.history.length - 1}${converged ? ' · convergido' : ''}`;
}

/**
 * Encuadre: todo lo que se dibuja (real, odometría, estimación, iteración anterior y
 * dónde quiere el cierre la pose 0). Se recalcula en cada fotograma, así que durante
 * la animación el zoom acompaña al movimiento.
 */
function currentView() {
  const shown = [state.scenario.truth, state.scenario.odometryEstimate, state.displayed];
  if (controls.showPrevious.checked && state.previous) shown.push(state.previous);
  const loop = state.edges.find((e) => e.kind === 'loop');
  if (loop) shown.push([compose(state.displayed[loop.from], loop.measurement)]);
  return new Projection(controls.trajectory, boundsOf(shown));
}

function render() {
  const theme = readTheme();
  drawTrajectories(controls.trajectory, currentView(), state, theme, {
    showTruth: controls.showTruth.checked,
    showPrevious: controls.showPrevious.checked,
  });
  const system = buildSystem(state.poses, state.edges, state.weights);
  drawHessian(controls.hessian, system, state.poses.length, theme);
  updateIterationTable();
  updateInfo(system);
  updateButtons();
}

// ---------- Eventos ----------

controls.step.addEventListener('click', () => iterate());
controls.converge.addEventListener('click', () => converge());
controls.reset.addEventListener('click', reset);
controls.newSeed.addEventListener('click', () => {
  state.seed = Math.floor(Math.random() * 100000);
  reset();
});
for (const input of [controls.drift, controls.odoAngle, controls.loopWeight]) {
  input.addEventListener('input', updateLabels);
  input.addEventListener('change', reset);
}
controls.loopEnabled.addEventListener('change', () => {
  updateLabels();
  reset();
});
for (const box of [controls.showTruth, controls.showPrevious]) box.addEventListener('change', render);

matchMedia('(prefers-color-scheme: dark)').addEventListener('change', render);
new MutationObserver(render).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

reset();
